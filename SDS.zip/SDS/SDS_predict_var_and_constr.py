import os
import warnings
# from transformers import T5Tokenizer, T5EncoderModel
import torch
import torch_geometric
import random
import time
import warnings
# import helper
from torch.optim.lr_scheduler import LambdaLR
from tqdm import tqdm
import re
def split_sample_by_blocks(sample_files, train_rate, block_size):
    sample_files = sorted(sample_files, key=lambda x: int(re.search(r'\d+', str(x)).group()))
    # sample_files = sample_files[-100:]
    # print([os.path.split(fn[0])[-1].split('-')[0] for fn in sample_files])
    # exit()
    random.seed(0)
    train_files = []
    valid_files = []

    num_blocks = (len(sample_files) + block_size - 1) // block_size

    for i in range(num_blocks):
        # Get the current block of files
        start_idx = i * block_size
        # Ensure end_idx doesn't exceed length of sample_files
        end_idx = min((i + 1) * block_size, len(sample_files))

        block_files = sample_files[start_idx:end_idx]

        random.shuffle(block_files)
        split_index = int(train_rate * len(block_files))
        train_files.extend(block_files[:split_index])
        valid_files.extend(block_files[split_index:])

    return train_files, valid_files



torch.backends.cudnn.enabled = True
torch.backends.cudnn.benchmark = True
# this file is to train a predict model. given a instance's bipartite graph as input, the model predict the binary distribution.

# 4 public datasets, IS, WA, CA, IP
# train model task
TaskName = "SDS4_2_hard"
warnings.filterwarnings("ignore")
# set folder
train_task = f'{TaskName}_train'
if not os.path.isdir(f'./train_logs'):
    os.mkdir(f'./train_logs')
if not os.path.isdir(f'./train_logs/{train_task}'):
    os.mkdir(f'./train_logs/{train_task}')
if not os.path.isdir(f'./pretrain'):
    os.mkdir(f'./pretrain')
if not os.path.isdir(f'./pretrain/{train_task}'):
    os.mkdir(f'./pretrain/{train_task}')
model_save_path = f'./pretrain/{train_task}/'
log_save_path = f"train_logs/{train_task}/"
log_file = open(f'{log_save_path}{train_task}_train.log', 'wb')

# set params
LEARNING_RATE = 0.001
NB_EPOCHS = 49
BATCH_SIZE = 1
accumulation_steps = 32
NUM_WORKERS = 0
WEIGHT_NORM = 100

# dataset task
meta_TaskName = TaskName
TaskName = "SDS"
DEVICE = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
DIR_BG = f'./dataset/train_hard/{TaskName}/BG'
DIR_SOL = f'./dataset/train_hard/{TaskName}/solution'
sample_names = os.listdir(DIR_BG)
sample_files = [(os.path.join(DIR_BG, name), os.path.join(DIR_SOL, name).replace('bg', 'sol')) for name in sample_names]
train_files, valid_files = split_sample_by_blocks(sample_files, 0.8, block_size=100)
multimodal = False



if TaskName == "IP":
    # Add position embedding for IP model, due to the strong symmetry
    from GCN import GNNPolicy_position as GNNPolicy
    from GCN import GraphDataset_position as GraphDataset
elif multimodal:
    from GCN import GraphDataset
    from GCN import GNNPolicy_multimodal as GNNPolicy
else:
    # SDS
    from SDS_GCN import GraphDataset_var_x_constr_2 as GraphDataset
    if meta_TaskName.startswith('SDS7'):
        from SDS_GCN import GNNPolicy_constraint_multiMLP as GNNPolicy
    else:
        from SDS_GCN import GNNPolicy_constraint as GNNPolicy



train_data = GraphDataset(train_files)
train_loader = torch_geometric.loader.DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=True,
                                                 num_workers=NUM_WORKERS)
valid_data = GraphDataset(valid_files)
valid_loader = torch_geometric.loader.DataLoader(valid_data, batch_size=BATCH_SIZE, shuffle=False,
                                                 num_workers=NUM_WORKERS)

PredictModel = GNNPolicy(TaskName).to(DEVICE)


def lr_lambda(epoch):
    return 0.98 ** ((epoch + 1) // 20)


def EnergyWeightNorm(task):
    if task == "IP":
        return 1
    elif task == "WA":
        return 100
    elif task == "CA" or task == "CA_m" or task == "CA_multi":
        return -4000
    elif task == "beasley":
        return 100
    elif task == "binkar":
        return 1000
    elif task == "ns":
        return 10000
    elif task == "neos":
        return 100
    elif task == "mas":
        return 10000
    elif task == "markshare":
        return 10
    elif task == "hisi_aps":
        return 500000 # 应该是负值
    elif task == "SDS": # Minimization
        return 1  # 对实例高质量解集合对应的目标值进行


def train(predict, data_loader, epoch, optimizer=None, weight_norm=1):
    """
    This function will process a whole epoch of training or validation, depending on whether an optimizer is provided.
    """
    if optimizer:
        predict.train()
        optimizer.zero_grad()
        desc = "Train "
    else:
        predict.eval()
        desc = "Valid "
    mean_loss = 0
    n_samples_processed = 0
    with torch.set_grad_enabled(optimizer is not None):
        for step, batch in enumerate(tqdm(data_loader, desc=f"{desc}Epoch {epoch}")):
            start_time = time.time()
            batch = batch.to(DEVICE)
            # get target solutions in list format
            solInd = batch.nsols
            con_num = batch.ncons
            label_num_constr = batch.nlabels_constr
            label_num_var_x = batch.nlabels_var_x
            label_num_var_rp = batch.nlabels_var_rp
            label_num_var_pur = batch.nlabels_var_pur
            label_num_var_r = batch.nlabels_var_r
            label_num_var_z = batch.nlabels_var_z

            target_sols = []
            target_vals = []
            target_masks_constr_rp_max = []
            target_labels_constr_rp_max = []
            target_labels_var_x = []
            target_masks_var_x = []
            target_labels_var_rp = []
            target_masks_var_rp = []
            target_labels_var_pur = []
            target_masks_var_pur = []
            target_labels_var_r = []
            target_masks_var_r = []
            target_labels_var_z = []
            target_masks_var_z = []
            solEndInd = 0
            valEndInd = 0
            conEndInd = 0
            labelEndInd_constr_rp_max = 0
            labelEndInd_var_x = 0
            labelEndInd_var_rp = 0
            labelEndInd_var_pur = 0
            labelEndInd_var_r = 0
            labelEndInd_var_z = 0
            # print("get data from batch:", time.time() - start_time)
            start_time = time.time()
            for i in range(solInd.shape[0]):  # for in batch
                nvar = len(batch.varInds[i][0][0])
                solStartInd = solEndInd
                solEndInd = solInd[i] * nvar + solStartInd
                conStartInd = conEndInd
                conEndInd = solInd[i] * con_num[i] + conStartInd
                valStartInd = valEndInd
                valEndInd = valEndInd + solInd[i]
                labelStartInd_constr_rp_max = labelEndInd_constr_rp_max
                labelEndInd_constr_rp_max = solInd[i] * label_num_constr[i] + labelStartInd_constr_rp_max
                labelStartInd_var_x = labelEndInd_var_x
                labelEndInd_var_x = solInd[i] * label_num_var_x[i] + labelStartInd_var_x
                labelStartInd_var_rp = labelEndInd_var_rp
                labelEndInd_var_rp = solInd[i] * label_num_var_rp[i] + labelStartInd_var_rp
                labelStartInd_var_pur = labelEndInd_var_pur
                labelEndInd_var_pur = solInd[i] * label_num_var_pur[i] + labelStartInd_var_pur
                labelStartInd_var_r = labelEndInd_var_r
                labelEndInd_var_r = solInd[i] * label_num_var_r[i] + labelStartInd_var_r
                labelStartInd_var_z = labelEndInd_var_z
                labelEndInd_var_z = solInd[i] * label_num_var_z[i] + labelStartInd_var_z


                sols = batch.solutions[solStartInd:solEndInd].reshape(1, nvar)
                constr_rp_max = batch.c_labels[labelStartInd_constr_rp_max:labelEndInd_constr_rp_max].reshape(1, label_num_constr[i])
                masks = batch.c_mask[conStartInd:conEndInd].reshape(1, con_num[i])[0]
                vals = batch.objVals[valStartInd:valEndInd]
                labels_var_x = batch.var_x_labels[labelStartInd_var_x:labelEndInd_var_x].reshape(1, label_num_var_x[i])
                masks_var_x = batch.var_x_masks[solStartInd:solEndInd].reshape(1, nvar)[0]
                labels_var_rp = batch.var_rp_labels[labelStartInd_var_rp:labelEndInd_var_rp].reshape(1, label_num_var_rp[i])
                masks_var_rp = batch.var_rp_masks[solStartInd:solEndInd].reshape(1, nvar)[0]
                labels_var_pur = batch.var_pur_labels[labelStartInd_var_pur:labelEndInd_var_pur].reshape(1, label_num_var_pur[i])
                masks_var_pur = batch.var_pur_masks[solStartInd:solEndInd].reshape(1, nvar)[0]
                labels_var_r = batch.var_r_labels[labelStartInd_var_r:labelEndInd_var_r].reshape(1, label_num_var_r[i])
                masks_var_r = batch.var_r_masks[solStartInd:solEndInd].reshape(1, nvar)[0]
                labels_var_z = batch.var_z_labels[labelStartInd_var_z:labelEndInd_var_z].reshape(1, label_num_var_z[i])
                masks_var_z = batch.var_z_masks[solStartInd:solEndInd].reshape(1, nvar)[0]
                # print('label_num_var_pur[i]', label_num_var_pur[i], 'masks_var_pur', masks_var_pur.sum())
                # print('label_num_var_z[i]', label_num_var_z[i], 'masks_var_z', masks_var_z.sum())

                # print('sols', sols.shape)
                # print('constr_rp_max', constr_rp_max.shape)
                # print('masks', masks.shape)
                # print('vals', vals.shape)
                # print('labels_var_x', labels_var_x.shape)
                # print('masks_var_x', masks_var_x.shape)
                # print('labels_var_rp', labels_var_rp.shape)
                # print('masks_var_rp', masks_var_rp.shape)
                # exit()


                target_sols.append(sols)
                target_labels_constr_rp_max.append(constr_rp_max)
                target_masks_constr_rp_max.append(masks)
                target_vals.append(vals)
                target_labels_var_x.append(labels_var_x)
                target_masks_var_x.append(masks_var_x)
                target_labels_var_rp.append(labels_var_rp)
                target_masks_var_rp.append(masks_var_rp)
                target_labels_var_pur.append(labels_var_pur)
                target_masks_var_pur.append(masks_var_pur)
                target_labels_var_r.append(labels_var_r)
                target_masks_var_r.append(masks_var_r)
                target_labels_var_z.append(labels_var_z)
                target_masks_var_z.append(masks_var_z)


            # print("parsing batch:",time.time() - start_time)
            mask_constr_rp_max = torch.cat(target_masks_constr_rp_max)
            mask_var_x = torch.cat(target_masks_var_x)
            mask_var_rp = torch.cat(target_masks_var_rp)
            mask_var_pur = torch.cat(target_masks_var_pur)
            mask_var_r = torch.cat(target_masks_var_r)
            mask_var_z = torch.cat(target_masks_var_z)
            # Compute the logits (i.e. pre-softmax activations) according to the policy on the concatenated graphs
            batch.constraint_features[torch.isinf(batch.constraint_features)] = 10  # remove nan value
            # predict the binary distribution, BD
            start_time = time.time()

            BD = predict(
                batch.constraint_features,
                batch.edge_index,
                batch.edge_attr,
                batch.variable_features,
                mask_constr_rp_max,
                mask_var_x,
                mask_var_rp
            )
            predict_constr_rp_max, predict_var_x, predict_var_rp = BD

            # compute loss
            loss = 0
            index_arrow = 0
            index_var_x = 0
            index_var_rp = 0

            index_cons = 0
            # in batch
            start_time = time.time()
            for ind, (sols, vals, labels_constr_rp_max, labels_var_x, labels_var_rp) in enumerate(zip(
                    target_sols, target_vals, target_labels_constr_rp_max,target_labels_var_x,target_labels_var_rp)):

                # get a binary mask
                varInds = batch.varInds[ind]
                varname_map = varInds[0][0]
                b_vars = varInds[1][0].long()

                focal_loss_gamma = 2
                ## predict constraints
                if labels_constr_rp_max.shape[1]>=2:
                    pre_cons = predict_constr_rp_max[index_cons: index_cons + label_num_constr[ind]].squeeze()
                    index_cons = index_cons + label_num_constr[ind]
                    pos_loss = -(pre_cons + 1e-8).log()[None, :] * (labels_constr_rp_max == 1).float()
                    neg_loss = -(1 - pre_cons + 1e-8).log()[None, :] * (labels_constr_rp_max == 0).float()
                    masked_con_loss = (pos_loss + neg_loss) # * weight[:, None]
                    loss += masked_con_loss.mean()
                    # print('masked_con_loss',masked_con_loss.mean().item())

                ## predict variables
                # get binary variables
                sols = sols[:, varname_map][:, b_vars]  # 注意，对于hisi来说，解是要预测0和1.
                pre_sols_var_x = predict_var_x[index_var_x:index_var_x + label_num_var_x[ind]].squeeze() # 当只含有一个变量时, 会出现错误
                index_var_x = index_var_x + label_num_var_x[ind]
                pre_sols_var_rp = predict_var_rp[index_var_rp:index_var_rp + label_num_var_rp[ind]].squeeze()
                index_var_rp = index_var_rp + label_num_var_rp[ind]
                if TaskName == 'SDS':
                    if labels_var_x.shape[1]>=2:  # squeeze() 如果shape==1会导致后续操作维度不一致
                        # 预测变量是否取值为0, 变量对应的最优值为0, 则labels==1
                        pos_loss_var_x = -(pre_sols_var_x + 1e-8).log()[None, :] * (labels_var_x == 1).float()
                        neg_loss_var_x = -(1 - pre_sols_var_x + 1e-8).log()[None, :] * (labels_var_x != 1).float()
                        var_loss_x = (pos_loss_var_x + neg_loss_var_x)  # * weight[:, None]
                        loss += var_loss_x.mean()

                    if labels_var_rp.shape[1]>=2:
                        pos_loss_var_rp = -(pre_sols_var_rp + 1e-8).log()[None, :] * (labels_var_rp == 1).float()
                        neg_loss_var_rp = -(1 - pre_sols_var_rp + 1e-8).log()[None, :] * (labels_var_rp != 1).float()
                        var_loss_rp = (pos_loss_var_rp + neg_loss_var_rp) # * weight[:, None]
                        loss += var_loss_rp.mean()
                else:
                    pos_loss = -(pre_sols_var_x + 1e-8).log()[None, :] * (sols == 1).float()
                    neg_loss = -(1 - pre_sols_var_x + 1e-8).log()[None, :] * (sols == 0).float()
                    var_loss = (pos_loss + neg_loss) * weight[:, None]
                    loss += var_loss.sum()


            # print("cal loss time:",time.time()-start_time)
            start_time = time.time()
            if optimizer is not None and loss != 0:
                loss.backward()
            if optimizer is not None and (step + 1) % accumulation_steps == 0:
                optimizer.step()
                optimizer.zero_grad()
            if optimizer is not None and step == len(data_loader) - 1:
                optimizer.step()
                optimizer.zero_grad()
            mean_loss += loss.item() if loss != 0 else 0
            n_samples_processed += batch.num_graphs
            # print("loss backward time:", time.time() - start_time)
    mean_loss /= n_samples_processed

    return mean_loss


optimizer = torch.optim.Adam(PredictModel.parameters(), lr=LEARNING_RATE)
scheduler = LambdaLR(optimizer, lr_lambda)
weight_norm = EnergyWeightNorm(TaskName) if not None else 100
best_val_loss = 99999
for epoch in range(NB_EPOCHS):

    begin = time.time()
    train_loss = train(PredictModel, train_loader, epoch, optimizer, weight_norm)
    scheduler.step()
    print(f"Epoch {epoch} Train loss: {train_loss:0.3f}")
    valid_loss = train(PredictModel, valid_loader, epoch, None, weight_norm)
    print(f"Epoch {epoch} Valid loss: {valid_loss:0.3f}")
    if valid_loss < best_val_loss:
        best_val_loss = valid_loss
        torch.save(PredictModel.state_dict(), model_save_path + 'x_2_model_best.pth')
    torch.save(PredictModel.state_dict(), model_save_path + 'x_2_model_last.pth')
    st = f'@epoch{epoch}   Train loss:{train_loss}   Valid loss:{valid_loss}    TIME:{time.time() - begin}\n'
    log_file.write(st.encode())
    log_file.flush()
print('done')


