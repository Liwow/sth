import os
import time
import datetime
import pickle
import random
import math
# from hisi_aps_p.new_data_gene import Para
from pyscipopt import Model, quicksum, SCIP_PARAMSETTING

import logging
logging.basicConfig(level=logging.DEBUG)

import random
import numpy as np
import copy
import multiprocessing


H = 36# 10 # 36  # fixed # 1->20min 36->12h
batch_lst = [25, 50, 75]  #  暂时固定，对影响模型求解的影响相对较小

item_num_min = 30 #6 # 30
item_num_max = 50 #10 #50
step_num_min = 500 #50 #500
step_num_max = 750 #75 #750 # 1500
recipe_num_min = math.floor(step_num_min/20*3)  # 75
recipe_num_max = math.ceil(step_num_max/10*3)  # 225
recipe_time_min = 1  # 1->20min
recipe_time_max = 36  # 36->12h
capability_recipe_num_min = 3 # 一个C包含的最少item数 recipe->capability 1对1, capability->recipe 1对多
capability_recipe_num_max = 4
#不需要指定capability数量, 随机生成，直到将所有recipe纳入capability管理
# capability_num_min = math.ceil(recipe_num_max/capability_recipe_num_min)
# capability_num_max = 2 * capability_num_min
capability_min = 20 # capc的最小值 20
capability_max = 108 # capc的最大值 108

outside_max_num = 5 # 外部来的item数量的最大值 非常稀疏 t*item*step 生成概率: 2/10000 value: 1~3*recipe(batch)
# #先跑一遍计算一下x的期望
# x_over_horizon 的均值是 150.34947904022724, 非0值比例是  0.00014982909284733472
# 初始库存的均值是 157.3008485420228, 非0值比例是  0.0012392099167844789
# 如果需要修改item等参数的话,
# outside_generate_p=0.0002*36*40*625/(H*(item_num_min+item_num_max)/2*(step_num_min+step_num_max)/2)
outside_generate_p = 0.0002
#初始库存需要特殊考虑, 其值更加密集
outside_generate_p_0 = 0.0015

assert recipe_time_max <= H

class Para(object):
    def __init__(self, T = H):
        self.T = T
        self.item_num = random.randint(item_num_min, item_num_max)
        self.recipe_num = random.randint(recipe_num_min, recipe_num_max)
        # self.capability_num = random.randint(capability_num_min, capability_num_max)
        self.outside_max_num = outside_max_num
        print('T', self.T,
              'item_num', self.item_num,
              'recipe_num', self.recipe_num,
              'outside_max_num', self.outside_max_num)
        assert capability_recipe_num_max < self.item_num
        # assert self.capability_num * capability_recipe_num_max < self.item_num * 2

        self.recipe_list = [] # 存储recipe名字的列表
        self.recipe_dic = {}  # 每个recipe对应的batch以及加工时间，如r0：{batch：50，time：4}
        self.item_dic = {}  # 每个物料的加工步以及加工时间，例如{r1,9}
        self.recipe_step = {}  # 得到每个r对应的item以及加工步，如（item0，0）、（item1，5），代表r要加工item0的0步。对应抽象模型中的IP(r)
        self.capability_list = [] # capability列表，元素为（[r1,r2,r3],20），也是就是r1、r2、r3的加工时长*使用的recipe r的数量之和，小于20。
        self.outside = {} # t时刻结束时收到的来自外部的(i,p)的数量，也就是得到了在制程步p的物料i的数量
        # self.step_num = step_num  # 应该是变化的

        self.num_var = 0

    def data_pre(self):
        self.recipe_data_gene()
        self.item_gene()
        self.capability_gene()
        self.outside_data_gene()
        self.recipe_step_gene()
        self.num_var = self.T * sum([len(self.item_dic[k]) for k in self.item_dic.keys()]) * 2 + self.recipe_num
        return {'recipe_dic': self.recipe_dic,
                'item_dic': self.item_dic,
                'recipe_step':self.recipe_step}

    def recipe_step_gene(self):
        for item_code in self.item_dic.keys():
            for step_order in self.item_dic[item_code].keys():
                recipe = self.item_dic[item_code][step_order]['recipe']
                self.recipe_step[recipe] = self.recipe_step.get(recipe, []) + [(item_code, step_order)]

    def outside_data_gene(self):
        for t in range(0, self.T+1):  # when t==0, initial inventory
            for item in self.item_dic.keys():
                for step_order in self.item_dic[item].keys():
                    p = outside_generate_p if t > 0 else outside_generate_p_0
                    if random.random() < p:
                        #item步骤p 上期对应的x*工艺p对应的batch数量
                        self.outside[t,item,step_order] = random.randint(0,outside_max_num)*self.recipe_dic[self.item_dic[item][step_order]['recipe']]['batch']

    def capability_gene(self):
        recipe = copy.deepcopy(self.recipe_list)
        random.shuffle(recipe) # 打乱

        # recipe对capability是1对1的关系
        while len(recipe)>0: # 当recipe全部纳入capability管理
            num = random.randint(capability_recipe_num_min, capability_recipe_num_max)
            num = min(num, len(recipe))
            assert num >= 1  # 至少有一个工艺被分配给capability管理

            r = recipe[:num]
            recipe = recipe[num:] # 更新recipe
            self.capability_list.append({'recipe': r, 'cap':random.randint(capability_min, capability_max)})

    def recipe_data_gene(self):
        for recipe_index in range(self.recipe_num):
            recipe_name = 'r' + str(recipe_index)
            recipe_time = random.randint(recipe_time_min, recipe_time_max)
            recipe_batch = random.choices(batch_lst, k=1)[0]
            self.recipe_list.append(recipe_name)
            self.recipe_dic[recipe_name] = {'time': recipe_time,
                                            'batch': recipe_batch}

    def item_gene(self):
        recipe_set = set(list(self.recipe_dic))
        for item_index in range(self.item_num):
            item_name = 'item' + str(item_index)

            item_steps_map = {}

            for step_index in range(random.randint(step_num_min, step_num_max)):
                # 考虑复杂的情形: 工艺会重复, 存在连续的工艺 y->x->x->y
                # 直接从recipe list 中随机选择每个步骤的工艺
                #TODO: 可能存在某些工艺始终没有被使用到，概率很小，因为 工艺数最大225，而item*step_num 最小item_num_min*step_num_min=15000
                #      可以考虑增加数据清洗的步骤
                cur_recipe = random.choices(list(recipe_set), k=1)[0]
                # 更新一下recipe_unused_set
                # recipe_unused_set -= {cur_recipe}
                cur_time = self.recipe_dic[cur_recipe]['time']
                item_steps_map[step_index] = {'recipe': cur_recipe,
                                              'time': cur_time}

            self.item_dic[item_name] = item_steps_map

def gen_para(idx,args, logger):

    para = Para()
    para.data_pre()

    path = args.dataset_path

    print("num_var:", para.num_var,
          'H:', para.T,
          'item_num:', para.item_num,
          'recipe_num:', para.recipe_num)

    ## save para
    # 暂时不需要para吧，如果不做校验的话
    # if not os.path.exists(path):
    #     os.makedirs(path)
    # para_path = os.path.join(path, 'para')
    # if not os.path.exists(para_path):
    #     os.makedirs(para_path)
    # with open(os.path.join(para_path, f'instance_idx{idx}_normal_para_v{para.num_var}-H{para.T}_i{para.item_num}_r{para.recipe_num}.pkl'), 'wb') as f:
    #     pickle.dump(para, f)

    # save instance
    instance_path = args.instance_path
    if not os.path.exists(instance_path):
        os.makedirs(instance_path)
    model_path = os.path.join(instance_path, f'instance_idx{idx}_normal_para_v{para.num_var}-H{para.T}_i{para.item_num}_r{para.recipe_num}.lp')
    # if  not os.path.exists(path + "/instance"):
    #     os.makedirs(path + "/instance")
    get_model(para,model_path, logger)

def get_model(para, model_path, logger):

    model = Model()
    x = {}
    s = {}
    inv = {}
    x_over_horizon = {}

    for recipe in para.recipe_list:
        s[recipe] = model.addVar(vtype='I', name=f's_{recipe}', lb=0)

    for t in range(1, para.T + 1):
        for item in para.item_dic.keys():
            for p in para.item_dic[item].keys():
                x[t, item, p] = model.addVar(vtype='I', name=f'x_t{t}_{item}_p{p}', lb=0.0)
                inv[t, item, p] = model.addVar(vtype='I', name=f'inv_t{t}_{item}_p{p}', lb=0.0)
                process_time = para.item_dic[item][p]['time']
                if t + process_time - 1 > para.T:
                    x_over_horizon[item, p] = x_over_horizon.get((item, p), []) + [x[t, item, p]]
    ## 约束构建
    # 使用s的约束
    numCon = 0
    for cap in para.capability_list:
        # cap要加上0.517，使得肯定不紧
        model.addCons(
            quicksum(para.recipe_dic[recipe]['time'] * s[recipe]
                     for recipe in cap['recipe']) <= cap['cap'] +0.517, name=f"cap_{numCon}")
        numCon += 1

    # r上生产的x不超过能力上限。
    numCon = 0
    for recipe in para.recipe_list:
        item_process = para.recipe_step[recipe]
        # con = pyscipopt.quicksum(x[t,item,p] for item, p in item_process for t in range(1,para.T+1)) <= para.recipe_dic[recipe]['batch'] *s[recipe]
        model.addCons(quicksum(x[t, item, p] for item, p in item_process for t in range(1, para.T + 1)) <=
                      para.recipe_dic[recipe]['batch'] * s[recipe], name=f"s_{numCon}")
        numCon += 1

    numInvInequality = 0
    numInvEquality = 0
    for t in range(1, para.T + 1):
        for item in para.item_dic.keys():
            for p in para.item_dic[item].keys():
                # 加工的前置条件
                # con1 = x.get((t, item, p), 0) <= inv.get((t-1,item,p), 0)
                if p > 0:
                    if t == 1:
                        model.addCons(x.get((t, item, p), 0) <= para.outside.get((0, item, p - 1), 0), name=f"invInequality_{numInvInequality}")
                    else:
                        model.addCons(x.get((t, item, p), 0) <= inv.get((t - 1, item, p - 1), 0), name=f"invInequality_{numInvInequality}")
                numInvInequality += 1

                # 库存转移方程
                recipe_time = para.item_dic[item][p]['time']
                # con2 = inv[t,item,p] == inv.get((t-1,item,p), 0) + x.get((t - recipe_time + 1,item,p), 0) \
                #               - x.get((t,item,p+1), 0) + para.outside.get((t,item,p), 0)
                temp_final_wip_var_lst = []
                if t == para.T:
                    temp_final_wip_var_lst = x_over_horizon.get((item, p), [])
                if t == 1:
                    model.addCons(
                        inv[t, item, p] == para.outside.get((0, item, p), 0) + x.get(
                            (t - recipe_time + 1, item, p), 0) \
                        - x.get((t, item, p + 1), 0) + para.outside.get((t, item, p), 0), name=f"invEquality_{numInvEquality}")
                elif t < para.T:
                    model.addCons(
                        inv[t, item, p] == inv.get((t - 1, item, p), 0) + x.get((t - recipe_time + 1, item, p), 0) \
                        - x.get((t, item, p + 1), 0) + para.outside.get((t, item, p), 0), name=f"invEquality_{numInvEquality}")
                elif t == para.T:
                    model.addCons(
                        inv[t, item, p] == inv.get((t - 1, item, p), 0) - x.get((t, item, p + 1), 0) \
                        + para.outside.get((t, item, p), 0) + quicksum(
                            x.get((t - k + 1, item, p), 0) for k in range(1, recipe_time + 1)), name=f"invEquality_{numInvEquality}")  # if t - k + 1 > 0
                numInvEquality += 1

    ## 目标函数
    obj = quicksum(
        (p + 1) * inv.get((para.T, item, p), 0)
        for item in para.item_dic.keys() for p in para.item_dic[item].keys()
    )
    model.setObjective(obj, sense='maximize')
    logger.info("The model is complete")
    model.writeProblem(filename=model_path, trans=False, genericnames=False)


def round2Int(var):
    var_floor = math.floor(var)
    var_ceil = math.ceil(var)
    if abs(var - var_floor) < abs(var - var_ceil):
        var_res =  var_floor
    else:
        var_res =  var_ceil

    assert abs(var_res - var) < 0.1
    return var_res


import argparse
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    """
    目前不保存para,只有在需要库存校验的时候才需要para,需要的话在gen_para把注释放出来
    """
    N_WORKERS = 100
    gen_train = False
    parser.add_argument('--gen_data', action='store_true')
    project_root_path = "/home/ei/workspace/chencan/jiajun_ps"
    if gen_train:
        parser.add_argument('--dataset_size', type=int, default=100)
        parser.add_argument('--dataset_path', type=str,
                            default=project_root_path + '/hisi_para/train') # 这是存para的
        parser.add_argument('--instance_path', type=str,
                            default=project_root_path + '/instance/train/hisi_aps') # 这是存instance的
        parser.add_argument('--seed', type=int, default=1234)
    else:
        parser.add_argument('--dataset_size', type=int, default=100)
        parser.add_argument('--dataset_path', type=str,
                            default=project_root_path + '/hisi_para/test')
        parser.add_argument('--instance_path', type=str,
                            default=project_root_path + '/instance/test/hisi_aps')
        # parser.add_argument('--seed', type=int, default=9527)
        parser.add_argument('--seed', type=int, default=4396)


    args = parser.parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed + 1)

    # generate the instances
    # 非并行
    gen_para_instance = True
    # if gen_para_instance:
    #     logger = logging.getLogger()
    #     for idx in range(args.dataset_size):
    #         gen_para(idx, args, logger)

    def call_gen_para(i):
        return gen_para(i, args, logger)

    # 并行
    if gen_para_instance:
        logger = logging.getLogger()
        pool = multiprocessing.Pool(processes=N_WORKERS)
        # pool.map(gen_para, range(args.dataset_size))
        pool.map(call_gen_para, range(args.dataset_size))
        pool.close()
        pool.join()


    solve_instance = False
    if solve_instance:
        instances_list = [f for f in os.listdir(args.instance_path) if f.endswith('.lp')]
        instances_list.sort()
        para_list = [p for p in os.listdir(os.path.join(args.dataset_path, 'para')) if p.endswith('.pkl')]
        para_list.sort()
        # print(instances_list)
        # exit()
        logger = logging.getLogger()
        costs = []
        solving_time = []
        BestSols = []
        for i, fn in enumerate(instances_list):
            model = Model()
            problem = os.path.join(args.instance_path, fn)
            model.readProblem(problem)
            # model.setRealParam("limits/gap", 0.01)
            # model.setIntParam("lp/threads", 4) # 这是什么参数

            # 从ps里拿的参数
            # model.setParam('randomization/randomseedshift', 0)
            # model.setParam('randomization/lpseed', 0)
            # model.setParam('randomization/permutationseed', 0)
            # model.setHeuristics(SCIP_PARAMSETTING.AGGRESSIVE)  # MIP focus

            start_time1 = time.process_time()
            model.optimize()
            end_time1 = time.process_time()
            cost = model.getObjVal()

            # print(cost)
            BestSol = model.getBestSol()
            vars = model.getVars()  # list

            x = {}
            inv = {}
            s = {}

            for var in vars:
                if var.name.startswith('x'):
                    # print(i.name)
                    # print(model.getVal(i))
                    x[var.name] = var
                elif var.name.startswith('inv'):
                    inv[var.name] = var

                elif var.name.startswith('s'):
                    s[var.name] = var
            costs.append(cost)
            BestSols.append(BestSol)
            solving_time.append(end_time1 - start_time1)



            x_over_horizon = {}
            check_instance = True
            if check_instance:

                para = para_list[i]
                para = os.path.join(args.dataset_path, 'para', para)
                with open(para, 'rb') as f:
                    parameter = pickle.load(f)
                # check cap
                # para.recipe_dic[recipe]['time'] * s[recipe] for recipe in cap['recipe']) <= cap['cap']
                for cap in parameter.capability_list:
                    sum_sr = 0
                    for recipe in cap['recipe']:
                        s_var = s['s_' + recipe]
                        s_var_val = model.getVal(s_var)
                        sum_sr += parameter.recipe_dic[recipe]['time'] * s_var_val
                    if sum_sr > cap['cap']:
                        raise Exception("cap约束不满足")

                # check sr
                for recipe in parameter.recipe_list:
                    r = recipe
                    sum_x = 0
                    for t in range(1, parameter.T + 1):
                        for item, p in parameter.recipe_step[recipe]:
                            pp = p
                            x_var = x['x_' + f't{t}_' + item + f"_p{p}"]
                            x_var_val = model.getVal(x_var)
                            sum_x += x_var_val

                    s_var = s['s_' + recipe]
                    s_var_val = model.getVal(s_var)
                    if sum_x > parameter.recipe_dic[recipe]['batch'] * s_var_val:
                        print("sum_x:", sum_x)
                        print("bt*sr:", parameter.recipe_dic[recipe]['batch'] * s_var_val)
                        raise Exception("sr约束不满足")

                # check inv平衡

                deduce_inv = {} # [i,p]
                deduce_product = {} # [t,i,p]

                # 初始库存
                for item in parameter.item_dic.keys():
                    for p in parameter.item_dic[item].keys():
                        inv_name = 'inv_' + item + f'_p{p}'
                        deduce_inv[inv_name] = parameter.outside.get((0, item, p), 0)

                for t in range(1, parameter.T + 1):
                    for item in parameter.item_dic.keys():
                        for p in parameter.item_dic[item].keys():
                            # T要单独处理，todo

                            # 得到当前的x
                            x_name = 'x_' + f't{t}_' + item + f"_p{p}"
                            x_var = x[x_name]
                            x_var_val = model.getVal(x_var)

                            # 校验库存
                            if p == 0: # 此时x无约束
                                pass
                            else:
                                # x_{t,i,p} < inv_{i, p-1}
                                inv_name = 'inv_' + item + f'_p{p - 1}'
                                last_p_inv = deduce_inv[inv_name] # 这里会出现不存在键的问题吗？
                                if x_var_val > last_p_inv:
                                        print(x_name,":",x_var_val)
                                        print(inv_name,":",last_p_inv)
                                        raise Exception("不满足库存")


                            # 更新生产
                            recipe_time = parameter.item_dic[item][p]['time']
                            product_name = f"t{t + recipe_time - 1}_" + item + f"_p{p}"
                            deduce_product[product_name] = x_var_val  #

                            ## 更新库存
                            # 库存增加(新的生产和外部来的)
                            inv_name = 'inv_' + item + f'_p{p}'
                            product_name = f"t{t}_" + item + f"_p{p}"
                            if deduce_inv.get(inv_name, None) is None: # 当前库存里没有这个inv，则添加键和值0
                                deduce_inv[inv_name] = 0
                            deduce_inv[inv_name] = (deduce_inv[inv_name] +
                                                    deduce_product.get(product_name,0) +
                                                    parameter.outside.get((t, item, p), 0))

                            # 库存减少(用于x生产的inv消耗)
                            if p == 0:
                                pass
                            else:
                                inv_name = 'inv_' + item + f'_p{p - 1}'
                                deduce_inv[inv_name] -= x_var_val

                print("库存推演和约束检查通过")

