import os
# from transformers import T5Tokenizer, T5EncoderModel
import torch
import torch_geometric
import gzip
import pickle
import numpy as np
import time
import utils
import re
# import helper

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


class GNNPolicy(torch.nn.Module):
    def __init__(self, TaskName=None):
        super().__init__()
        emb_size = 64
        cons_nfeats = 4
        edge_nfeats = 1
        var_nfeats = 6

        # CONSTRAINT EMBEDDING
        self.cons_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(cons_nfeats),
            torch.nn.Linear(cons_nfeats, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
        )

        # EDGE EMBEDDING
        self.edge_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(edge_nfeats),
        )

        # VARIABLE EMBEDDING
        self.var_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(var_nfeats),
            torch.nn.Linear(var_nfeats, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
        )

        self.conv_v_to_c = BipartiteGraphConvolution()
        self.conv_c_to_v = BipartiteGraphConvolution()

        # self.cross_attention = torch.nn.MultiheadAttention(embed_dim=64, num_heads=8, batch_first=True)

        self.conv_v_to_c2 = BipartiteGraphConvolution()
        self.conv_c_to_v2 = BipartiteGraphConvolution()

        self.output_module = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, 1, bias=False),
        )

    def forward(
            self, constraint_features, edge_indices, edge_features, variable_features
            # , multimodal_features
    ):
        reversed_edge_indices = torch.stack([edge_indices[1], edge_indices[0]], dim=0)

        # First step: linear embedding layers to a common dimension (64)
        constraint_features = self.cons_embedding(constraint_features)
        edge_features = self.edge_embedding(edge_features)
        variable_features = self.var_embedding(variable_features)

        # Two half convolutions
        constraint_features = self.conv_v_to_c(
            variable_features, reversed_edge_indices, edge_features, constraint_features
        )
        variable_features = self.conv_c_to_v(
            constraint_features, edge_indices, edge_features, variable_features
        )

        constraint_features = self.conv_v_to_c2(
            variable_features, reversed_edge_indices, edge_features, constraint_features
        )
        variable_features = self.conv_c_to_v2(
            constraint_features, edge_indices, edge_features, variable_features
        )

        # A final MLP on the variable features
        output = self.output_module(variable_features).squeeze(-1)

        return output


class BipartiteGraphConvolution(torch_geometric.nn.MessagePassing):
    """
    The bipartite graph convolution is already provided by pytorch geometric and we merely need
    to provide the exact form of the messages being passed.
    """

    def __init__(self):
        super().__init__("add")
        emb_size = 64

        self.feature_module_left = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size)
        )
        self.feature_module_edge = torch.nn.Sequential(
            torch.nn.Linear(1, emb_size, bias=False)
        )
        self.feature_module_right = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size, bias=False)
        )
        self.feature_module_final = torch.nn.Sequential(
            torch.nn.LayerNorm(emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
        )

        self.post_conv_module = torch.nn.Sequential(torch.nn.LayerNorm(emb_size))

        # output_layers
        self.output_module = torch.nn.Sequential(
            torch.nn.Linear(2 * emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
        )

    def forward(self, left_features, edge_indices, edge_features, right_features):
        """
        This method sends the messages, computed in the message method.
        """

        output = self.propagate(
            edge_indices,
            size=(left_features.shape[0], right_features.shape[0]),
            node_features=(left_features, right_features),
            edge_features=edge_features,
        )
        b = torch.cat([self.post_conv_module(output), right_features], dim=-1)
        a = self.output_module(
            torch.cat([self.post_conv_module(output), right_features], dim=-1)
        )

        return self.output_module(
            torch.cat([self.post_conv_module(output), right_features], dim=-1)
        )

    def message(self, node_features_i, node_features_j, edge_features):
        # node_features_i,the node to be aggregated
        # node_features_j,the neighbors of the node i

        # print("node_features_i:",node_features_i.shape)
        # print("node_features_j",node_features_j.shape)
        # print("edge_features:",edge_features.shape)

        output = self.feature_module_final(
            self.feature_module_left(node_features_i)
            + self.feature_module_edge(edge_features)
            + self.feature_module_right(node_features_j)
        )

        return output


class GraphDataset(torch_geometric.data.Dataset):
    """
    This class encodes a collection of graphs, as well as a method to load such graphs from the disk.
    It can be used in turn by the data loaders provided by pytorch geometric.
    """

    def __init__(self, sample_files):
        super().__init__(root=None, transform=None, pre_transform=None)
        self.sample_files = sample_files

    def len(self):
        return len(self.sample_files)

    def process_sample(self, filepath):
        BGFilepath, solFilePath = filepath
        with open(BGFilepath, "rb") as f:
            bgData = pickle.load(f)
        try:
            with open(solFilePath, 'rb') as f:
                solData = pickle.load(f)
        except Exception as e:
            print(f"Error: {e}, file: {solFilePath}")

        BG = bgData
        varNames = solData['var_names']

        sols = solData['sols'][:50]  # [0:300]
        objs = solData['objs'][:50]  # [0:300]

        sols = np.round(sols, 0)
        return BG, sols, objs, varNames

    def get(self, index):
        """
        This method loads a node bipartite graph observation as saved on the disk during data collection.
        """

        # nbp, sols, objs, varInds, varNames = self.process_sample(self.sample_files[index])
        BG, sols, objs, varNames = self.process_sample(self.sample_files[index])

        A, v_map, v_nodes, c_nodes, b_vars = BG

        constraint_features = c_nodes
        edge_indices = A._indices()

        variable_features = v_nodes
        edge_features = A._values().unsqueeze(1)
        edge_features = torch.ones(edge_features.shape)

        constraint_features[np.isnan(constraint_features)] = 1

        graph = BipartiteNodeData(
            torch.FloatTensor(constraint_features),
            torch.LongTensor(edge_indices),
            torch.FloatTensor(edge_features),
            torch.FloatTensor(variable_features),
        )

        # We must tell pytorch geometric how many nodes there are, for indexing purposes
        graph.num_nodes = constraint_features.shape[0] + variable_features.shape[0]
        graph.solutions = torch.FloatTensor(sols).reshape(-1)
        graph.objVals = torch.FloatTensor(objs)
        graph.nsols = sols.shape[0]
        graph.ntvars = variable_features.shape[0]
        graph.varNames = varNames
        varname_dict = {}
        varname_map = []
        i = 0
        for iter in varNames:
            varname_dict[iter] = i
            i += 1
        for iter in v_map:
            varname_map.append(varname_dict[iter])

        varname_map = torch.tensor(varname_map)

        graph.varInds = [[varname_map], [b_vars]]

        return graph


class BipartiteNodeData(torch_geometric.data.Data):
    """
    This class encode a node bipartite graph observation as returned by the `ecole.observation.NodeBipartite`
    observation function in a format understood by the pytorch geometric data handlers.
    """

    def __init__(
            self,
            constraint_features,
            edge_indices,
            edge_features,
            variable_features,

    ):
        super().__init__()
        self.constraint_features = constraint_features
        self.edge_index = edge_indices
        self.edge_attr = edge_features
        self.variable_features = variable_features

    def __inc__(self, key, value, store, *args, **kwargs):
        """
        We overload the pytorch geometric method that tells how to increment indices when concatenating graphs
        for those entries (edge index, candidates) for which this is not obvious.
        """
        if key == "edge_index":
            return torch.tensor(
                [[self.constraint_features.size(0)], [self.variable_features.size(0)]]
            )
        elif key == "candidates":
            return self.variable_features.size(0)
        else:
            return super().__inc__(key, value, *args, **kwargs)


class GNNPolicy_position(torch.nn.Module):
    def __init__(self, TaskName=None):
        super().__init__()
        emb_size = 64
        cons_nfeats = 4
        edge_nfeats = 1
        var_nfeats = 18

        # CONSTRAINT EMBEDDING
        self.cons_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(cons_nfeats),
            torch.nn.Linear(cons_nfeats, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
        )

        # EDGE EMBEDDING
        self.edge_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(edge_nfeats),
        )

        # VARIABLE EMBEDDING
        self.var_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(var_nfeats),
            torch.nn.Linear(var_nfeats, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
        )

        self.conv_v_to_c = BipartiteGraphConvolution()
        self.conv_c_to_v = BipartiteGraphConvolution()

        self.conv_v_to_c2 = BipartiteGraphConvolution()
        self.conv_c_to_v2 = BipartiteGraphConvolution()

        self.output_module = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, 1, bias=False),
        )

    def forward(
            self, constraint_features, edge_indices, edge_features, variable_features
    ):
        reversed_edge_indices = torch.stack([edge_indices[1], edge_indices[0]], dim=0)

        # First step: linear embedding layers to a common dimension (64)
        constraint_features = self.cons_embedding(constraint_features)
        edge_features = self.edge_embedding(edge_features)
        variable_features = self.var_embedding(variable_features)

        # Two half convolutions
        constraint_features = self.conv_v_to_c(
            variable_features, reversed_edge_indices, edge_features, constraint_features
        )
        variable_features = self.conv_c_to_v(
            constraint_features, edge_indices, edge_features, variable_features
        )

        constraint_features = self.conv_v_to_c2(
            variable_features, reversed_edge_indices, edge_features, constraint_features
        )
        variable_features = self.conv_c_to_v2(
            constraint_features, edge_indices, edge_features, variable_features
        )

        # A final MLP on the variable features
        output = self.output_module(variable_features).squeeze(-1)

        return output



# GNN predict constraints and variable
class GNNPolicy_constraint_multiMLP(torch.nn.Module):
    def __init__(self, TaskName=None):
        super().__init__()
        emb_size = 64
        cons_nfeats = 4
        edge_nfeats = 1
        var_nfeats = 6

        # CONSTRAINT EMBEDDING
        self.cons_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(cons_nfeats),
            torch.nn.Linear(cons_nfeats, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
        )

        # EDGE EMBEDDING
        self.edge_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(edge_nfeats),
        )

        # VARIABLE EMBEDDING
        self.var_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(var_nfeats),
            torch.nn.Linear(var_nfeats, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
        )

        self.conv_v_to_c = BipartiteGraphConvolution()
        self.conv_c_to_v = BipartiteGraphConvolution()

        # self.cross_attention = torch.nn.MultiheadAttention(embed_dim=64, num_heads=8, batch_first=True)

        self.conv_v_to_c2 = BipartiteGraphConvolution()
        self.conv_c_to_v2 = BipartiteGraphConvolution()

        self.conv_c_to_v3 = BipartiteGraphConvolution()

        self.mlp_constr_rp_max = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, 1, bias=False),
        )

        self.mlp_var_x = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, 1, bias=False),
        )

        self.mlp_var_rp = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, 1, bias=False),
        )

        self.mlp_var_pur = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, 1, bias=False),
        )
        self.mlp_var_r = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, 1, bias=False),
        )
        self.mlp_var_z = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, 1, bias=False),
        )

    def forward(
            self, constraint_features, edge_indices, edge_features, variable_features,
            mask_constr_rp_max=None,
            mask_var_x=None,
            mask_var_rp=None,
            mask_var_pur=None,
            mask_var_r=None,
            mask_var_z=None,
            # , multimodal_features
    ):
        reversed_edge_indices = torch.stack([edge_indices[1], edge_indices[0]], dim=0)

        # First step: linear embedding layers to a common dimension (64)
        constraint_features = self.cons_embedding(constraint_features)
        edge_features = self.edge_embedding(edge_features)
        variable_features = self.var_embedding(variable_features)

        # Two half convolutions
        variable_features = self.conv_c_to_v(
            constraint_features, edge_indices, edge_features, variable_features
        )
        constraint_features = self.conv_v_to_c(
            variable_features, reversed_edge_indices, edge_features, constraint_features
        )

        variable_features = self.conv_c_to_v2(
            constraint_features, edge_indices, edge_features, variable_features
        )

        constraint_features = self.conv_v_to_c2(
            variable_features, reversed_edge_indices, edge_features, constraint_features
        )

        variable_features = self.conv_c_to_v3(
            constraint_features, edge_indices, edge_features, variable_features
        )

        if mask_constr_rp_max is not None:
            mask_constraint_features = constraint_features[mask_constr_rp_max == 1]
        else:
            mask_constraint_features = constraint_features
        con_output = torch.sigmoid(self.mlp_constr_rp_max(mask_constraint_features).squeeze(-1))

        if mask_var_x is not None:
            mask_var_features_x = variable_features[mask_var_x == 1]
            var_output = torch.sigmoid(self.mlp_var_x(mask_var_features_x).squeeze(-1))
        else:
            var_output = torch.sigmoid(self.mlp_var_x(variable_features).squeeze(-1))

        if mask_var_rp is not None:
            mask_var_features_rp = variable_features[mask_var_rp == 1]
            var_output_rp = torch.sigmoid(self.mlp_var_rp(mask_var_features_rp).squeeze(-1))
        else:
            var_output_rp = torch.tensor([])

        if mask_var_pur is not None:
            mask_var_features_pur = variable_features[mask_var_pur == 1]
            var_output_pur = torch.sigmoid(self.mlp_var_pur(mask_var_features_pur).squeeze(-1))
        else:
            var_output_pur = torch.tensor([])

        if mask_var_r is not None:
            mask_var_features_r = variable_features[mask_var_r == 1]
            var_output_r = torch.sigmoid(self.mlp_var_r(mask_var_features_r).squeeze(-1))
        else:
            var_output_r = torch.tensor([])

        if mask_var_z is not None:
            mask_var_features_z = variable_features[mask_var_z == 1]
            var_output_z = torch.sigmoid(self.mlp_var_z(mask_var_features_z).squeeze(-1))
        else:
            var_output_z = torch.tensor([])

        return con_output, var_output, var_output_rp, var_output_pur, var_output_r, var_output_z


class GNNPolicy_constraint(torch.nn.Module):
    def __init__(self, TaskName=None):
        super().__init__()
        emb_size = 64
        cons_nfeats = 4
        edge_nfeats = 1
        var_nfeats = 6

        # CONSTRAINT EMBEDDING
        self.cons_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(cons_nfeats),
            torch.nn.Linear(cons_nfeats, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
        )

        # EDGE EMBEDDING
        self.edge_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(edge_nfeats),
        )

        # VARIABLE EMBEDDING
        self.var_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(var_nfeats),
            torch.nn.Linear(var_nfeats, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
        )

        self.conv_v_to_c = BipartiteGraphConvolution()
        self.conv_c_to_v = BipartiteGraphConvolution()

        # self.cross_attention = torch.nn.MultiheadAttention(embed_dim=64, num_heads=8, batch_first=True)

        self.conv_v_to_c2 = BipartiteGraphConvolution()
        self.conv_c_to_v2 = BipartiteGraphConvolution()

        self.conv_c_to_v3 = BipartiteGraphConvolution()

        self.mlp_constr_rp_max = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, 1, bias=False),
        )

        self.mlp_var_x = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, 1, bias=False),
        )

        self.mlp_var_rp = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, 1, bias=False),
        )

    def forward(
            self, constraint_features, edge_indices, edge_features, variable_features,
            mask_constr_rp_max=None,
            mask_var_x=None,
            mask_var_rp=None
            # , multimodal_features
    ):
        reversed_edge_indices = torch.stack([edge_indices[1], edge_indices[0]], dim=0)

        # First step: linear embedding layers to a common dimension (64)
        constraint_features = self.cons_embedding(constraint_features)
        edge_features = self.edge_embedding(edge_features)
        variable_features = self.var_embedding(variable_features)

        # Two half convolutions
        variable_features = self.conv_c_to_v(
            constraint_features, edge_indices, edge_features, variable_features
        )
        constraint_features = self.conv_v_to_c(
            variable_features, reversed_edge_indices, edge_features, constraint_features
        )

        variable_features = self.conv_c_to_v2(
            constraint_features, edge_indices, edge_features, variable_features
        )

        constraint_features = self.conv_v_to_c2(
            variable_features, reversed_edge_indices, edge_features, constraint_features
        )

        variable_features = self.conv_c_to_v3(
            constraint_features, edge_indices, edge_features, variable_features
        )

        if mask_constr_rp_max is not None:
            mask_constraint_features = constraint_features[mask_constr_rp_max == 1]
        else:
            mask_constraint_features = constraint_features
        con_output = torch.sigmoid(self.mlp_constr_rp_max(mask_constraint_features).squeeze(-1))

        if mask_var_x is not None:
            mask_var_features_x = variable_features[mask_var_x == 1]
            var_output = torch.sigmoid(self.mlp_var_x(mask_var_features_x).squeeze(-1))
        else:
            var_output = torch.sigmoid(self.mlp_var_x(variable_features).squeeze(-1))

        if mask_var_rp is not None:
            mask_var_features_rp = variable_features[mask_var_rp == 1]
            var_output_rp = torch.sigmoid(self.mlp_var_rp(mask_var_features_rp).squeeze(-1))
        else:
            var_output_rp = torch.tensor([])


        return con_output, var_output, var_output_rp


class GraphDataset_constraint(torch_geometric.data.Dataset):

    def __init__(self, sample_files):
        super().__init__(root=None, transform=None, pre_transform=None)
        self.sample_files = sample_files

    def len(self):
        return len(self.sample_files)

    def process_sample(self, filepath):
        BGFilepath, solFilePath = filepath
        with open(BGFilepath, "rb") as f:
            bgData = pickle.load(f)
        try:
            with open(solFilePath, 'rb') as f:
                solData = pickle.load(f)
        except Exception as e:
            print(f"Error: {e}, file: {solFilePath}")

        BG = bgData
        varNames = solData['var_names']


        sols = solData['sols'][:5]  # [0:100]
        objs = solData['objs'][:5]  # [0:100]
        slacks = solData['slacks'][:5] # [0:100]
        sols = np.round(sols, 0)
        return BG, sols, objs, varNames, slacks

    def get(self, index):
        """
        This method loads a node bipartite graph observation as saved on the disk during data collection.
        """

        # nbp, sols, objs, varInds, varNames = self.process_sample(self.sample_files[index])
        BG, sols, objs, varNames, slacks = self.process_sample(self.sample_files[index])

        A, v_map, v_nodes, c_nodes, b_vars = BG

        constraint_features = c_nodes
        edge_indices = A._indices()

        variable_features = v_nodes
        edge_features = A._values().unsqueeze(1)
        edge_features = torch.ones(edge_features.shape)

        constraint_features[np.isnan(constraint_features)] = 1

        graph = BipartiteNodeData(
            torch.FloatTensor(constraint_features),
            torch.LongTensor(edge_indices),
            torch.FloatTensor(edge_features),
            torch.FloatTensor(variable_features),
        )

        c_mask = []
        c_labels = []
        for slack in slacks:
            mask = [1 if con[2] in ['<', '>'] else 0 for con in slack] # 不等式为1,等式为0
            labels = [1 if con[1] == 0 and con[2] in ['<', '>'] else 0 for con in slack] # 不等式&slack=0为1，其他为0
            mask = torch.tensor(mask, dtype=torch.float32)
            labels = torch.tensor(labels, dtype=torch.float32)
            c_mask.append(mask)
            c_labels.append(labels[mask == 1])  # 取出满足的元素,也就是说，等式都没了
        graph.c_labels = torch.cat(c_labels).reshape(-1)
        graph.c_mask = torch.cat(c_mask).reshape(-1)

        # We must tell pytorch geometric how many nodes there are, for indexing purposes
        graph.num_nodes = constraint_features.shape[0] + variable_features.shape[0]
        graph.solutions = torch.FloatTensor(sols).reshape(-1)

        graph.objVals = torch.FloatTensor(objs)
        graph.ncons = len(slacks[1])
        graph.nlabels = c_labels[1].size()[0]
        graph.nsols = sols.shape[0]
        graph.ntvars = variable_features.shape[0]
        graph.varNames = varNames
        varname_dict = {}
        varname_map = []
        i = 0
        for iter in varNames:
            varname_dict[iter] = i
            i += 1
        for iter in v_map:
            varname_map.append(varname_dict[iter])

        varname_map = torch.tensor(varname_map)

        graph.varInds = [[varname_map], [b_vars]]

        return graph



class GraphDataset_var_x_constr_2(torch_geometric.data.Dataset):

    def __init__(self, sample_files):
        super().__init__(root=None, transform=None, pre_transform=None)
        self.sample_files = sample_files

    def len(self):
        return len(self.sample_files)

    def process_sample(self, filepath):
        # print(filepath)
        BGFilepath, solFilePath = filepath
        with open(BGFilepath, "rb") as f:
            bgData = pickle.load(f)
        try:
            with open(solFilePath, 'rb') as f:
                solData = pickle.load(f)
        except Exception as e:
            print(f"Error: {e}, file: {solFilePath}")

        BG = bgData
        varNames = solData['var_names']
        var_map_sol_i = solData['var_map_sol_i']
        con_map_sol_i = solData['con_map_sol_i']

        # print('sols', solData['sols'].shape)
        # exit()

        sols = solData['sols'][:1]  # [0:100]
        objs = solData['objs'][:1]  # [0:100]
        slacks = solData['slacks'][:1] # [0:100]
        sols = np.round(sols, 0)
        return BG, sols, objs, varNames, slacks, var_map_sol_i, con_map_sol_i

    def get(self, index):
        """
        This method loads a node bipartite graph observation as saved on the disk during data collection.
        """

        # nbp, sols, objs, varInds, varNames = self.process_sample(self.sample_files[index])
        BG, sols, objs, varNames, slacks, var_map_sol_i,con_map_sol_i = self.process_sample(self.sample_files[index])

        A, v_map, v_nodes, c_nodes, b_vars, c_map, i_map_v, i_map_c = BG

        constraint_features = c_nodes
        edge_indices = A._indices()

        variable_features = v_nodes
        edge_features = A._values().unsqueeze(1)
        edge_features = torch.ones(edge_features.shape)

        constraint_features[np.isnan(constraint_features)] = 1

        graph = BipartiteNodeData(
            torch.FloatTensor(constraint_features),
            torch.LongTensor(edge_indices),
            torch.FloatTensor(edge_features),
            torch.FloatTensor(variable_features),
        )

        ## 变量mask: x, rp
        ##
        var_x_masks = []
        var_x_labels = []
        var_rp_masks= []
        var_rp_labels = []
        var_pur_masks = []
        var_pur_labels = []
        var_r_masks = []
        var_r_labels = []
        var_z_masks = []
        var_z_labels = []
        ## SDS
        x_re = re.compile(f'^x(_\d+)+')
        rp_re = re.compile(f'^rp(_\d+)+')
        ### For SDS5
        # x_re = re.compile(f'(x|rp|z|r|pur)(_\d+)+')
        # rp_re = re.compile(f'xxxxxxxx(_\d+)+')

        ### For SDS7
        pur_re = re.compile(f'^xxxxxxxxxxpur(_\d+)+')  # 排除pur变量
        r_re = re.compile(f'^xxxxxxxxxr(_\d+)+')  # 如上
        z_re = re.compile(f'^xxxxxxxxxxz(_\d+)+')  # 如上

        for sol in sols:
            var_x_mask = [1 if x_re.match(i_map_v[i]) is not None else 0 for i in range(len(v_nodes))]
            # x变量为1, 其他变量为0
            var_x_label = [1 if x_re.match(i_map_v[i]) is not None and sol[var_map_sol_i[i_map_v[i]]] < 1e-4 else 0 for i in range(len(v_nodes))]
            # x变量中值为0的变量为1, 其他为0
            var_x_mask = torch.tensor(var_x_mask, dtype=torch.float32)
            var_x_label = torch.tensor(var_x_label, dtype=torch.float32)
            var_x_masks.append(var_x_mask)
            var_x_labels.append(var_x_label[var_x_mask == 1])  # 取出mask为1的元素，也就是变量x

            var_rp_mask = [1 if rp_re.match(i_map_v[i]) is not None else 0 for i in range(len(v_nodes))]
            # rp变量为1, 其他变量为0
            var_rp_label = [1 if rp_re.match(i_map_v[i]) is not None and sol[var_map_sol_i[i_map_v[i]]] < 1e-4 else 0 for i in range(len(v_nodes))]
            # rp变量中值为0的变量为1, 其他为0
            var_rp_mask = torch.tensor(var_rp_mask, dtype=torch.float32)
            var_rp_label = torch.tensor(var_rp_label, dtype=torch.float32)
            var_rp_masks.append(var_rp_mask)
            var_rp_labels.append(var_rp_label[var_rp_mask == 1])

            # pur
            var_pur_mask = [1 if pur_re.match(i_map_v[i]) is not None else 0 for i in range(len(v_nodes))]
            var_pur_label = [1 if pur_re.match(i_map_v[i]) is not None and sol[var_map_sol_i[i_map_v[i]]] < 1e-4 else 0 for
                           i in range(len(v_nodes))]
            var_pur_mask = torch.tensor(var_pur_mask, dtype=torch.float32)
            var_pur_label = torch.tensor(var_pur_label, dtype=torch.float32)
            var_pur_masks.append(var_pur_mask)
            var_pur_labels.append(var_pur_label[var_pur_mask == 1])  # 取出mask为1的元素，也就是变量x


            # r
            var_r_mask = [1 if r_re.match(i_map_v[i]) is not None else 0 for i in range(len(v_nodes))]
            var_r_label = [1 if r_re.match(i_map_v[i]) is not None and sol[var_map_sol_i[i_map_v[i]]] < 1e-4 else 0
                             for i in range(len(v_nodes))]
            var_r_mask = torch.tensor(var_r_mask, dtype=torch.float32)
            var_r_label = torch.tensor(var_r_label, dtype=torch.float32)
            var_r_masks.append(var_r_mask)
            var_r_labels.append(var_r_label[var_r_mask == 1])  # 取出mask为1的元素，也就是变量x

            # z
            var_z_mask = [1 if z_re.match(i_map_v[i]) is not None else 0 for i in range(len(v_nodes))]
            var_z_label = [1 if z_re.match(i_map_v[i]) is not None and sol[var_map_sol_i[i_map_v[i]]] < 1e-4 else 0
                             for i in range(len(v_nodes))]
            var_z_mask = torch.tensor(var_z_mask, dtype=torch.float32)
            var_z_label = torch.tensor(var_z_label, dtype=torch.float32)
            var_z_masks.append(var_z_mask)
            var_z_labels.append(var_z_label[var_z_mask == 1])  # 取出mask为1的元素，也就是变量x

        graph.var_x_labels = torch.cat(var_x_labels).reshape(-1)
        graph.var_x_masks = torch.cat(var_x_masks).reshape(-1)
        graph.nlabels_var_x = var_x_labels[0].size()[0]
        graph.var_rp_labels = torch.cat(var_rp_labels).reshape(-1)
        graph.var_rp_masks = torch.cat(var_rp_masks).reshape(-1)
        graph.nlabels_var_rp = var_rp_labels[0].size()[0]

        graph.var_pur_labels = torch.cat(var_pur_labels).reshape(-1)
        graph.var_pur_masks = torch.cat(var_pur_masks).reshape(-1)
        graph.nlabels_var_pur = var_pur_labels[0].size()[0]

        graph.var_r_labels = torch.cat(var_r_labels).reshape(-1)
        graph.var_r_masks = torch.cat(var_r_masks).reshape(-1)
        graph.nlabels_var_r = var_r_labels[0].size()[0]

        graph.var_z_labels = torch.cat(var_z_labels).reshape(-1)
        graph.var_z_masks = torch.cat(var_z_masks).reshape(-1)
        graph.nlabels_var_z = var_z_labels[0].size()[0]


        # print('graph.var_x_labels', graph.var_x_labels.shape)
        # print('graph.var_rp_labels', graph.var_rp_labels.shape)

        ## rp_max约束mask
        ##
        c_mask = []
        c_labels = []
        ## SDS
        rp_max_re = re.compile(f'^rp_max(_\d+)+')
        ### For SDS6
        # rp_max_re = re.compile(f'xxxxxxx(_\d+)+')
        for slack in slacks:  # item: (ConstrName, slack, Sense)
            mask = [1 if slack[con_map_sol_i[i_map_c[i]]][2] in ['<', '>']
                         and rp_max_re.match(i_map_c[i]) is not None else 0
                    for i in range(len(c_nodes))]
            # mask = [1 if con[2] in ['<', '>'] and rp_max_re.match(con[0]) is not None else 0 for con in slack]
            # 约束为不等式并且为rp_max约束, 为1,其余为0
            labels = [1 if slack[con_map_sol_i[i_map_c[i]]][1] == 0
                           and slack[con_map_sol_i[i_map_c[i]]][2] in ['<', '>']
                           and rp_max_re.match(i_map_c[i]) is not None else 0
                      for i in range(len(c_nodes))]
            # 约束为不等式并且为rp_max约束,并且是紧约束为1,其余为0
            mask = torch.tensor(mask, dtype=torch.float32)
            labels = torch.tensor(labels, dtype=torch.float32)
            c_mask.append(mask)
            c_labels.append(labels[mask == 1])  # 取出mask为1的元素，也就是不等式2
        graph.c_labels = torch.cat(c_labels).reshape(-1)
        graph.c_mask = torch.cat(c_mask).reshape(-1)
        graph.nlabels_constr = c_labels[0].size()[0]
        # print('graph.c_labels',graph.c_labels.shape)

        # We must tell pytorch geometric how many nodes there are, for indexing purposes
        graph.num_nodes = constraint_features.shape[0] + variable_features.shape[0]
        graph.solutions = torch.FloatTensor(sols).reshape(-1)

        graph.objVals = torch.FloatTensor(objs)
        graph.ncons = len(slacks[0])
        graph.nsols = sols.shape[0]
        graph.ntvars = variable_features.shape[0]
        graph.varNames = varNames
        varname_dict = {}
        varname_map = []
        i = 0
        for iter in varNames:
            varname_dict[iter] = i
            i += 1
        for iter in v_map:
            varname_map.append(varname_dict[iter])

        varname_map = torch.tensor(varname_map)

        graph.varInds = [[varname_map], [b_vars]]

        return graph

class GraphDataset_position(torch_geometric.data.Dataset):
    """
    This class encodes a collection of graphs, as well as a method to load such graphs from the disk.
    It can be used in turn by the data loaders provided by pytorch geometric.
    """

    def __init__(self, sample_files):
        super().__init__(root=None, transform=None, pre_transform=None)
        self.sample_files = sample_files

    def len(self):
        return len(self.sample_files)

    def process_sample(self, filepath):
        BGFilepath, solFilePath = filepath
        with open(BGFilepath, "rb") as f:
            bgData = pickle.load(f)
        with open(solFilePath, "rb") as f:
            solData = pickle.load(f)

        BG = bgData
        varNames = solData['var_names']

        sols = solData['sols'][:50]  # [0:300]
        objs = solData['objs'][:50]  # [0:300]

        sols = np.round(sols, 0)
        return BG, sols, objs, varNames

    def get(self, index):
        """
        This method loads a node bipartite graph observation as saved on the disk during data collection.
        """

        # nbp, sols, objs, varInds, varNames = self.process_sample(self.sample_files[index])
        BG, sols, objs, varNames = self.process_sample(self.sample_files[index])

        A, v_map, v_nodes, c_nodes, b_vars = BG

        constraint_features = c_nodes
        edge_indices = A._indices()

        variable_features = v_nodes
        edge_features = A._values().unsqueeze(1)
        edge_features = torch.ones(edge_features.shape)

        lens = variable_features.shape[0]
        feature_widh = 12  # max length 4095
        position = torch.arange(0, lens, 1)

        position_feature = torch.zeros(lens, feature_widh)
        for i in range(len(position_feature)):
            binary = str(bin(position[i]).replace('0b', ''))

            for j in range(len(binary)):
                position_feature[i][j] = int(binary[-(j + 1)])

        v = torch.concat([variable_features, position_feature], dim=1)

        variable_features = v

        graph = BipartiteNodeData(
            torch.FloatTensor(constraint_features),
            torch.LongTensor(edge_indices),
            torch.FloatTensor(edge_features),
            torch.FloatTensor(variable_features),
        )

        # We must tell pytorch geometric how many nodes there are, for indexing purposes
        graph.num_nodes = constraint_features.shape[0] + variable_features.shape[0]
        graph.solutions = torch.FloatTensor(sols).reshape(-1)

        graph.objVals = torch.FloatTensor(objs)
        graph.nsols = sols.shape[0]
        graph.ntvars = variable_features.shape[0]
        graph.varNames = varNames
        varname_dict = {}
        varname_map = []
        i = 0
        for iter in varNames:
            varname_dict[iter] = i
            i += 1
        for iter in v_map:
            varname_map.append(varname_dict[iter])

        varname_map = torch.tensor(varname_map)

        graph.varInds = [[varname_map], [b_vars]]

        return graph





def postion_get(variable_features):
    lens = variable_features.shape[0]
    feature_widh = 12  # max length 4095
    position = torch.arange(0, lens, 1)

    position_feature = torch.zeros(lens, feature_widh)
    for i in range(len(position_feature)):
        binary = str(bin(position[i]).replace('0b', ''))

        for j in range(len(binary)):
            position_feature[i][j] = int(binary[-(j + 1)])

    variable_features = torch.FloatTensor(variable_features.cpu())
    v = torch.concat([variable_features, position_feature], dim=1).to(DEVICE)
    return v
