import gurobipy
import json
from gurobipy import GRB
import argparse

import helper
import test
import random
import os
import numpy as np
import torch
from time import time
from helper import get_a_new2
from tqdm import tqdm
import optvpy
import pandas as pd
import re
import time
import pickle


# set the folder of test-dataset on root_task_type
root_task_type = 'instance/test'
# set the ratio of variables or constraints to fix to 0 or tight
k0_var_x_ratio = 0.1
k0_var_rp_ratio = 0
tight_constr_rp_max_ratio = 0.2
OPTV_ONLY = False

DEVICE = torch.device("cpu" if torch.cuda.is_available() else "cpu")
random.seed(0)
torch.manual_seed(0)
torch.cuda.manual_seed(0)

TaskName = "SDS4_2_hard"  # SDS3_focal_loss
if TaskName == "CA_multi":
    multimodal = True
# load pretrained model
if TaskName == "IP":
    # Add position embedding for IP model, due to the strong symmetry
    from GCN import GNNPolicy_position as GNNPolicy, postion_get
elif multimodal:
    from GCN import GNNPolicy_multimodal as GNNPolicy
else:
    from SDS_GCN import GNNPolicy_constraint as GNNPolicy

model_name = f'{TaskName}.pth'
# modelName = varType + "_" + constrType
modelName = "x_2"
pathstr = f'./pretrain/{TaskName}_train/{modelName}_model_best.pth'
policy = GNNPolicy().to(DEVICE)
state = torch.load(pathstr, map_location=torch.device(DEVICE))
policy.load_state_dict(state)

# /home/ei/miniconda3/envs/msps/bin/python SDS_test_predict_constr_var.py
delta_x,delta_rp = 0,0  ## 需要调整
delta_pur,delta_r,delta_z = 0,0,0
k0_var_pur_ratio,k0_var_r_ratio,k0_var_z_ratio = 0,0,0
varTypes = ['x'+str(int(100*k0_var_x_ratio)), 'rp'+str(int(100*k0_var_rp_ratio))
            , 'pur'+str(int(100*k0_var_pur_ratio)), 'r'+str(int(100*k0_var_r_ratio))
            , 'z'+str(int(100*k0_var_z_ratio))]
constrTypes = ['rp_max'+str(int(100*tight_constr_rp_max_ratio))]

# set log folder
solver = 'optv'

if not OPTV_ONLY:
    test_task = (f"{TaskName}_{solver}-{'_'.join(root_task_type.split('/'))}_PS_constr-{'-'.join(constrTypes)}_var-{'-'.join(varTypes)}-delta_x{delta_x}_rp{delta_rp}")
else:
    test_task = 'OPTV_baseline'

# 4 public datasets, IS, WA, CA, IP
TaskName_run_name = TaskName
TaskName = 'SDS'

# sample_names = sorted([fn for fn in os.listdir(f'./{root_task_type}/{TaskName}') if fn.endswith('.lp') or fn.endswith('.mps')])
# WFL_folder = "lp-verify5/WFL136986#201228#18141/models_18141"
WFL_folder = "lp-verify3/WFL136533#212715#18141/models_18141"
sample_names = sorted([fn for fn in os.listdir(f'./{root_task_type}/WFL_{TaskName}/' + WFL_folder) if fn.endswith('.lp') or fn.endswith('.mps')])
# if not os.path.isdir(f'./logs'):
#     os.mkdir(f'./logs')
# if not os.path.isdir(f'./logs/{TaskName}'):
#     os.mkdir(f'./logs/{TaskName}')
# if not os.path.isdir(f'./logs/{TaskName}/{test_task}'):
#     os.mkdir(f'./logs/{TaskName}/{test_task}')
# log_folder = f'./logs/WFl_{TaskName}/' + WFL_folder + f'/{test_task}'
log_folder = f'./logs/WFl_{TaskName}/' + WFL_folder

if not os.path.isdir(log_folder):
    os.makedirs(log_folder)

with open(f"{log_folder}/parameter.txt","w") as f:
    f.write(f"{TaskName}_{solver}-{'_'.join(root_task_type.split('/'))}_PS_constr-{'-'.join(constrTypes)}_var-{'-'.join(varTypes)}-delta_x{delta_x}_rp{delta_rp}")  # 自带文件关闭功能，不需要再写f.close()

count = 0
subop_total = 0
infeas_total = 0
time_total = 0
max_subop = -1
max_infeas = -1
max_time = 0

ALL_Test = len(sample_names)
epoch = 1
TestNum = round(ALL_Test / epoch)
# TestNum = ALL_Test

# for ins_num in tqdm(range(TestNum)):
#     test_ins_name = sample_names[ins_num]
#     ins_name_to_read = f'./instance/test/{TaskName}/{test_ins_name}'
dataframes = []
print("TestNum:",TestNum)
for e in range(epoch):
    for ins_num in range(TestNum):

        test_ins_name = sample_names[e * TestNum + ins_num]

        ins_name_to_read = f'./{root_task_type}/WFL_{TaskName}/' + WFL_folder + f'/{test_ins_name}'
        print("当前实例：",ins_name_to_read)

        # ## optv
        if OPTV_ONLY:
            t3 = time.time()
            optvLogPath = f'{log_folder}/optv_{test_ins_name}.log'
            optvEnv = optvpy.OPTVEnv(optvLogPath)
            optvModel = optvpy.OPTVModel(optvEnv)
            optvModel.Read(ins_name_to_read)
            optvModel.Optimize()
            originalOBJ = optvModel.Get(optvpy.OPTVDblAttr.OBJ_VAL)
            print("optv最优解:", optvModel.Get(optvpy.OPTVDblAttr.OBJ_VAL))
            t4 = time.time()

            optv_test_log_folder = 'optv201'
            os.makedirs(os.path.join(os.path.dirname(ins_name_to_read), 'solutions', optv_test_log_folder), exist_ok=True)
            pickle.dump({
                'ins_name': test_ins_name,
                'obj': optvModel.Get(optvpy.OPTVDblAttr.OBJ_VAL),
                "varNum": optvModel.Get(optvpy.OPTVIntAttr.NUM_VARS),
                "constrNum": optvModel.Get(optvpy.OPTVIntAttr.NUM_CONSTRS),
                "RUN_TIME": optvModel.Get(optvpy.OPTVDblAttr.RUN_TIME),
                "OBJ_VAL": optvModel.Get(optvpy.OPTVDblAttr.OBJ_VAL), # 目前这个可能不需要
                "total_runtime": t4-t3
            }, open(os.path.join(os.path.dirname(ins_name_to_read), 'solutions', optv_test_log_folder, test_ins_name + '.pkl'), 'wb'))
            continue


        ########################################################################################################################
        # Load optv results
        optv_opt_solutions = pickle.load(
            open(os.path.join(os.path.dirname(ins_name_to_read), 'solutions', 'optv201', test_ins_name + '.pkl'), 'rb'))

        Statistics = pd.Series(
            {
                "instance": test_ins_name,
                "varNum": optv_opt_solutions['varNum'],  # optvModel.Get(optvpy.OPTVIntAttr.NUM_VARS),
                "constrNum": optv_opt_solutions['constrNum'],  # optvModel.Get(optvpy.OPTVIntAttr.NUM_CONSTRS),
                "RUN_TIME": optv_opt_solutions['RUN_TIME'],  # optvModel.Get(optvpy.OPTVDblAttr.RUN_TIME),
                "OBJ_VAL": optv_opt_solutions['OBJ_VAL'],  # optvModel.Get(optvpy.OPTVDblAttr.OBJ_VAL), # 目前这个可能不需要
                "fixConstrType": '-'.join(constrTypes),
                "fixVarTypr": '-'.join(varTypes),
            }
        )
        # dataframes.append(Statistics)
        # continue

        PS_stage0_start_time = time.time()
        optvLogPath = f'{log_folder}/optv_{test_ins_name}_timelimited10.log'
        optvEnv0 = optvpy.OPTVEnv(optvLogPath)
        optvEnv0.Set(optvpy.OPTVDblParam.TIME_LIMIT, 10)  # 单位s
        optvModel0 = optvpy.OPTVModel(optvEnv0)
        optvModel0.Read(ins_name_to_read)
        optvModel0.Optimize()

        Statistics["varNum"] = optvModel0.Get(optvpy.OPTVIntAttr.NUM_VARS)
        Statistics["constrNum"] = optvModel0.Get(optvpy.OPTVIntAttr.NUM_CONSTRS)
        # 限OPTVDblParam::TIME_LIMIT
        if optvModel0.Get(optvpy.OPTVIntAttr.STATUS) == optvpy.OPTV_OPTIMAL:
            originalOBJ = optvModel0.Get(optvpy.OPTVDblAttr.OBJ_VAL)
            print("optv最优解:", optvModel0.Get(optvpy.OPTVDblAttr.OBJ_VAL))

            Statistics["fixed_OBJ_VAL"] = optvModel0.Get(optvpy.OPTVDblAttr.OBJ_VAL)
            # Statistics["OBJ_Degrade(%)"] = (Statistics["fixed_OBJ_VAL"] - Statistics["OBJ_VAL"]) / Statistics[
            #     "OBJ_VAL"] * 100
            Statistics["fix_RUN_TIME"] = optvModel0.Get(optvpy.OPTVDblAttr.RUN_TIME)
            # Statistics["timeImprove(%)"] = (Statistics["RUN_TIME"] - Statistics["fix_RUN_TIME"]) / Statistics[
            #     "RUN_TIME"] * 100
            Statistics["fixConstrNum"] = 0
            Statistics["fixConstrPercentInAll"] = 0  # 占总约束数的多少
            Statistics["fixVarNum"] = 0
            Statistics["fixVarNum_x"] = 0
            Statistics["fixVarNum_rp"] = 0
            Statistics["fixVarPercentInAll"] = 0  # 占总变量数的多少,好像可以直接用k
            # Statistics["subopt"] = 0
            dataframes.append(Statistics)
            resultDf = pd.DataFrame(dataframes)
            resultDf.to_csv(f"{log_folder}/optv_SDS_WFL_{test_task}.csv", index=False)
            continue
        PS_stage0_time = time.time() - PS_stage0_start_time

        # get bipartite graph as input
        PS_stage1_start_time = time.time()
        A, v_map, v_nodes, c_nodes, b_vars, c_map, i_map_v, i_map_c = get_a_new2(ins_name_to_read)
        constraint_features = c_nodes.cpu() # todo:cpu?
        # TODO 与训练脚本的处理不一致
        constraint_features[torch.tensor(np.isnan(constraint_features),dtype=torch.bool).clone().detach()] = 1  # remove nan value
        variable_features = v_nodes
        if TaskName == "IP":
            variable_features = postion_get(variable_features)
        edge_indices = A._indices()
        edge_features = A._values().unsqueeze(1)
        edge_features = torch.ones(edge_features.shape)

        var_x_masks = []
        var_rp_masks = []
        ## SDS
        x_re = re.compile(f'x(_\d+)+')
        rp_re = re.compile(f'rp(_\d+)+')

        var_x_mask = [1 if x_re.match(i_map_v[i]) is not None else 0 for i in range(len(v_nodes))]
        vars_x_varName = [i_map_v[i] for i in range(len(v_nodes)) if var_x_mask[i] == 1]
        var_x_mask = torch.tensor(var_x_mask, dtype=bool)
        var_rp_mask = [1 if rp_re.match(i_map_v[i]) is not None else 0 for i in range(len(v_nodes))]
        vars_rp_varName = [i_map_v[i] for i in range(len(v_nodes)) if var_rp_mask[i] == 1]
        var_rp_mask = torch.tensor(var_rp_mask, dtype=bool)

        # m3只用来读取cons，获得关于约束类型的mask
        rp_max_re = re.compile(f'rp_max(_\d+)+')
        c_masks = [1 if rp_max_re.match(i_map_c[i]) is not None else 0
                   for i in range(len(c_nodes))]

        # consName = [allConsName[i] for i ,mask in enumerate(c_masks) if mask==1]
        consName = [i_map_c[i] for i in range(len(c_nodes)) if c_masks[i] == 1]
        print("c_masks:", sum(c_masks))
        c_masks = torch.tensor(c_masks, dtype=bool)

        # prediction
        BD = policy(
            constraint_features.to(DEVICE),
            edge_indices.to(DEVICE),
            edge_features.to(DEVICE),
            variable_features.to(DEVICE),
            c_masks,
            var_x_mask,
            var_rp_mask,
        )
        pre_cons, predict_var_x,predict_var_rp = BD
        pre_cons = pre_cons.cpu().squeeze()
        predict_var_x = predict_var_x.cpu().squeeze()
        # print(pre_cons.shape,predict_var_x.shape,predict_var_rp.shape)
        # exit()
        assert len(predict_var_x) == len(vars_x_varName), f'{len(predict_var_x)} == {len(vars_x_varName)}'
        assert len(predict_var_rp) == len(vars_rp_varName), f'{len(predict_var_rp)} == {len(vars_rp_varName)}'
        assert len(pre_cons) == len(consName), f'{len(pre_cons)} == {len(consName)}'

        k0_var_x = int(k0_var_x_ratio * len(predict_var_x))
        k0_var_rp = int(k0_var_rp_ratio*len(predict_var_rp))
        tight_constr_rp_max = int(tight_constr_rp_max_ratio * len(pre_cons))

        # align the variable name betweend the output and the solver
        # var构建 scores
        var_x_scores = []
        for i in range(len(predict_var_x)):
            var_x_scores.append([i,vars_x_varName[i], predict_var_x[i].item(), -1, 'BINARY'])
        var_x_scores.sort(key=lambda x: x[2], reverse=True)  # reverse=True，按概率从大到小排序
        var_rp_scores = []
        for i in range(len(predict_var_rp)):
            var_rp_scores.append([i, vars_rp_varName[i], predict_var_rp[i].item(), -1, 'BINARY'])
        var_rp_scores.sort(key=lambda x: x[2], reverse=True)  # reverse=True，按概率从大到小排序

        var_fixer = 0
        # fixing variable picked by confidence scores
        if TaskName == "SDS":
            count0_x = 0
            for i in range(len(var_x_scores)):
                if count0_x < k0_var_x:
                    var_x_scores[i][3] = 0  # 概率大的固定为0
                    count0_x += 1
                    var_fixer += 1
            count0_rp = 0
            for i in range(len(var_rp_scores)):
                if count0_rp < k0_var_rp:
                    var_rp_scores[i][3] = 0  # 概率大的固定为0
                    count0_rp += 1
                    var_fixer += 1
            print(f'instance: {test_ins_name}, '
                  f'fix x {count0_x} 0s and '
                  f'fix rp {count0_rp} 0s, delta {delta_x}. ')
        else:
            raise Exception("unknown taskname")


        # 约束构建 scores
        constr_scores = []
        for i in range(len(pre_cons)):
            constr_scores.append([i, consName[i], pre_cons[i].item(), -1])
        constr_scores.sort(key=lambda x: x[2], reverse=True)  # reverse=True，按概率从大到小排序

        constr_fixer = 0
        count_tight_rp_max = 0
        for i in range(len(pre_cons)):
            if count_tight_rp_max < tight_constr_rp_max:
                constr_scores[i][3] = 1  # 概率大的固定为tight constraint
                count_tight_rp_max += 1
                constr_fixer += 1
        PS_stage1_time = time.time() - PS_stage1_start_time


        # originalOBJ = Statistics['OBJ_VAL']

        PS_stage2_start_time = time.time()
        ## optv固定约束和变量
        # 重新得到一个optv模型，目前用再读入的方式
        optvLogPath = f'{log_folder}/optv_fixed_{test_ins_name}.log'
        optvEnv = optvpy.OPTVEnv(optvLogPath)
        optvFixedModel = optvpy.OPTVModel(optvEnv)
        optvFixedModel.Read(ins_name_to_read)

        ## 固定约束
        # fix constrs in optv
        for score in constr_scores:
            if score[3] == 1: # tight constr
                con = optvFixedModel.GetConstrByName(score[1])
                UB = con.Get(optvpy.OPTVDblAttr.UB)
                con.Set(optvpy.OPTVDblAttr.LB, UB)

        allVars = optvFixedModel.GetVars()
        sortedAllVars = sorted(allVars, key=lambda v: v.Get(optvpy.OPTVStrAttr.NAME))
        optv_variabels_map = {}
        for v in sortedAllVars:  # get a dict (variable map), varname:var clasee
            optv_variabels_map[v.Get(optvpy.OPTVStrAttr.NAME)] = v

        # optv固定变量
        # 固定x变量
        # scores里[3]为1的固定
        fixVarNum = 0
        fixVarNum_x = 0
        tmp_var_xs = []
        for i in range(len(var_x_scores)):
            if var_x_scores[i][3] < 0:
                continue
            else: # set to 0
                tar_var = optv_variabels_map[var_x_scores[i][1]]
                x_star = var_x_scores[i][3]
                if x_star == 0:
                    if delta_x <= 0:
                        UB = tar_var.Get(optvpy.OPTVDblAttr.UB)
                        LB = tar_var.Get(optvpy.OPTVDblAttr.LB)
                        tar_var.Set(optvpy.OPTVDblAttr.UB, LB)
                    else:
                        tmp_var_x = optvFixedModel.AddVar(lb=0,ub=optvpy.OPTV_INF,obj=0,type=optvpy.OPTV_CONTINUOUS, name=f'tmp_var_x-{var_x_scores[i][1]}')
                        tmp_var_xs.append(tmp_var_x)
                        # lb(float) –变量的下界。
                        # • ub(float) –变量的上界。
                        # • obj(float) –变量在目标函数中的系数。
                        # • type(str) – OPTV_CONTINUOUS, OPTV_INTEGER,
                        # OPTV_BINARY.
                        # • name(str) –变量名称。
                        optvFixedModel.AddConstr(tmp_var_x - tar_var, lhs=0, rhs=optvpy.OPTV_INF, name=f'tmp_var_x_constr0-{var_x_scores[i][1]}')
                        optvFixedModel.AddConstr(tmp_var_x + tar_var, lhs=0, rhs=optvpy.OPTV_INF, name=f'tmp_var_x_constr1-{var_x_scores[i][1]}')
                    fixVarNum_x += 1
        if len(tmp_var_xs) > 0 :
            all_tmp_x = 0
            for tmp_var in tmp_var_xs:
                all_tmp_x+=tmp_var
            optvFixedModel.AddConstr(all_tmp_x-delta_x, lhs=-optvpy.OPTV_INF, rhs=0, name=f'tmp_var_x_constr-delta')

        # 固定rp变量
        fixVarNum_rp = 0
        tmp_var_rps = []
        for i in range(len(var_rp_scores)):
            if var_rp_scores[i][3] < 0:
                continue
            else: # set to 0
                tar_var = optv_variabels_map[var_rp_scores[i][1]]
                x_star = var_rp_scores[i][3]
                if x_star == 0:
                    if delta_rp <= 0:
                        UB = tar_var.Get(optvpy.OPTVDblAttr.UB)
                        LB = tar_var.Get(optvpy.OPTVDblAttr.LB)
                        tar_var.Set(optvpy.OPTVDblAttr.UB, LB)
                    else:
                        tmp_var_rp = optvFixedModel.AddVar(lb=0, ub=optvpy.OPTV_INF, obj=0, type=optvpy.OPTV_CONTINUOUS,
                                                          name=f'tmp_var_rp-{var_rp_scores[i][1]}')
                        tmp_var_rps.append(tmp_var_rp)
                        optvFixedModel.AddConstr(tmp_var_rp - tar_var, lhs=0, rhs=optvpy.OPTV_INF,
                                                 name=f'tmp_var_rp_constr0-{var_rp_scores[i][1]}')
                        optvFixedModel.AddConstr(tmp_var_rp + tar_var, lhs=0, rhs=optvpy.OPTV_INF,
                                                 name=f'tmp_var_rp_constr1-{var_rp_scores[i][1]}')
                    fixVarNum_rp += 1
        if len(tmp_var_rps) > 0 :
            all_tmp_rp = 0
            for tmp_var in tmp_var_rps:
                all_tmp_rp+=tmp_var
            optvFixedModel.AddConstr(all_tmp_rp-delta_rp, lhs=-optvpy.OPTV_INF, rhs=0, name=f'tmp_var_rp_constr-delta')

        fixVarNum = fixVarNum_x + fixVarNum_rp
        PS_stage2_time = time.time() - PS_stage2_start_time


        # 固定后optv求解
        optvFixedModel.Update()
        optvFixedModel.Optimize()

        # todo:在原问题中可行的判断

        Statistics["fixConstrNum"] = constr_fixer
        Statistics["fixConstrPercentInAll"] = constr_fixer / Statistics["constrNum"] * 100  # 占总约束数的多少
        Statistics["fixVarNum"] = fixVarNum
        Statistics["fixVarNum_x"] = fixVarNum_x
        Statistics["fixVarNum_rp"] = fixVarNum_rp
        Statistics["fixVarPercentInAll"] =  fixVarNum / Statistics["varNum"] * 100  # 占总变量数的多少,好像可以直接用k
        Statistics["fixed_OBJ_VAL"] = optvFixedModel.Get(optvpy.OPTVDblAttr.OBJ_VAL)
        # Statistics["OBJ_Degrade(%)"] = (Statistics["fixed_OBJ_VAL"] - Statistics["OBJ_VAL"]) / Statistics["OBJ_VAL"] * 100
        Statistics["fix_RUN_TIME"] = optvFixedModel.Get(optvpy.OPTVDblAttr.RUN_TIME)+PS_stage0_time+PS_stage2_time+PS_stage1_time
        # Statistics["timeImprove(%)"] = (Statistics["RUN_TIME"] - Statistics["fix_RUN_TIME"]) / Statistics["RUN_TIME"] * 100
        Statistics["rp_maxConstrNum"] = len(pre_cons)
        Statistics["fixConstrPercent"] = constr_fixer / Statistics["rp_maxConstrNum"] * 100  # 占总约束数的多少


        # subopt
        predictOBJ = optvFixedModel.Get(optvpy.OPTVDblAttr.OBJ_VAL)
        solveStatus = optvFixedModel.Get(optvpy.OPTVIntAttr.STATUS)
        objSense = optvFixedModel.Get(optvpy.OPTVIntAttr.OBJ_SENSE)
        # if solveStatus == 1:
        #     # 求解成功
        #     if objSense == 1: # 最小化问题
        #         subopt = (predictOBJ - originalOBJ) / abs(originalOBJ)
        #     elif objSense == -1: # 最大化问题
        #         subopt = (originalOBJ - predictOBJ) / abs(originalOBJ)
        #     else:
        #         raise Exception("unknown sense")
        # else:
        #     # 其他情况
        #     subopt = 1e10
        # Statistics["subopt"] = subopt

        dataframes.append(Statistics)
        resultDf = pd.DataFrame(dataframes)
        resultDf.to_csv(f"{log_folder}/optv_SDS_WFL_{test_task}.csv", index=False)

print('Model:', pathstr)
print('root_task_type', root_task_type)
print('log_folder:', log_folder)


# resultDf = pd.DataFrame(dataframes)
# resultDf.to_csv(f"{log_folder}/optv_constr{constrType}_var{varType}.csv", index=False)
