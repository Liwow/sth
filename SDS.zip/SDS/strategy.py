import gurobipy
import json
from gurobipy import GRB
import argparse

import helper
import test
import random
import os
import numpy as np
import torch
from time import time
from helper import get_a_new2
from tqdm import tqdm
import optvpy
import pandas as pd
import re
import time
import pickle
from SDS_GCN import GNNPolicy_constraint as GNNPolicy

k0_var_x_ratio = 0.1
k0_var_rp_ratio = 0
tight_constr_rp_max_ratio = 0.2

TaskName = "SDS4_2_hard"
DEVICE = torch.device("cpu" if torch.cuda.is_available() else "cpu")
random.seed(0)
torch.manual_seed(0)
torch.cuda.manual_seed(0)

model_name = f'{TaskName}.pth'
modelName = "x_2"
pathstr = f'./pretrain/{TaskName}_train/{modelName}_model_best.pth'
policy = GNNPolicy().to(DEVICE)
state = torch.load(pathstr, map_location=torch.device(DEVICE))
policy.load_state_dict(state)

delta_x,delta_rp = 0,0
k0_var_pur_ratio,k0_var_r_ratio,k0_var_z_ratio = 0,0,0

varTypes = ['x'+str(int(100*k0_var_x_ratio)), 'rp'+str(int(100*k0_var_rp_ratio))
            , 'pur'+str(int(100*k0_var_pur_ratio)), 'r'+str(int(100*k0_var_r_ratio))
            , 'z'+str(int(100*k0_var_z_ratio))]
constrTypes = ['rp_max'+str(int(100*tight_constr_rp_max_ratio))]

solver = 'optv'
TaskName = 'SDS'
log_folder = f'./logs/WFl_{TaskName}/' 
if not os.path.isdir(log_folder):
    os.makedirs(log_folder)

test_ins_name = ""
ins_name_to_read = ""

def get_features(ins_read:str):
    A, v_map, v_nodes, c_nodes, b_vars, c_map, i_map_v, i_map_c = get_a_new2(ins_name_to_read)
    constraint_features = c_nodes.cpu()
    constraint_features[torch.tensor(np.isnan(constraint_features),dtype=torch.bool).clone().detach()] = 1  # remove nan value
    variable_features = v_nodes
    edge_indices = A._indices()
    edge_features = A._values().unsqueeze(1)
    edge_features = torch.ones(edge_features.shape)
    var_x_masks = []
    var_rp_masks = []
    x_re = re.compile(f'x(_\d+)+')
    rp_re = re.compile(f'rp(_\d+)+')
    var_x_mask = [1 if x_re.match(i_map_v[i]) is not None else 0 for i in range(len(v_nodes))]
    vars_x_varName = [i_map_v[i] for i in range(len(v_nodes)) if var_x_mask[i] == 1]
    var_x_mask = torch.tensor(var_x_mask, dtype=bool)
    var_rp_mask = [1 if rp_re.match(i_map_v[i]) is not None else 0 for i in range(len(v_nodes))]
    vars_rp_varName = [i_map_v[i] for i in range(len(v_nodes)) if var_rp_mask[i] == 1]
    var_rp_mask = torch.tensor(var_rp_mask, dtype=bool)
    rp_max_re = re.compile(f'rp_max(_\d+)+')
    c_masks = [1 if rp_max_re.match(i_map_c[i]) is not None else 0
                       for i in range(len(c_nodes))]
    consName = [i_map_c[i] for i in range(len(c_nodes)) if c_masks[i] == 1]

    c_masks = torch.tensor(c_masks, dtype=bool)
    features = {
        "constraint_features":constraint_features,
        "edge_indices":edge_indices,
        "edge_features":edge_features,
        "variable_features":variable_features,
        "c_masks":c_masks,
        "var_x_mask":var_x_mask,
        "var_rp_mask":var_rp_mask,
        "vars_x_varName":vars_x_varName,
        "vars_rp_varName":vars_rp_varName,
    }
    return features, consName

def forward(features, policy):
    BD = policy(
        features["constraint_features"].to(DEVICE),
        features["edge_indices"].to(DEVICE),
        features["edge_features"].to(DEVICE),
        features["variable_features"].to(DEVICE),
        features["c_masks"],
        features["var_x_mask"],
        features["var_rp_mask"],
    )
    pre_cons, predict_var_x,predict_var_rp = BD
    pre_cons = pre_cons.cpu().squeeze()
    predict_var_x = predict_var_x.cpu().squeeze()
    # print(pre_cons.shape,predict_var_x.shape,predict_var_rp.shape)
    # exit()
    assert len(predict_var_x) == len(features["vars_x_varName"]), f'{len(predict_var_x)} == {len(features["vars_x_varName"])}'
    assert len(predict_var_rp) == len(features["vars_rp_varName"]), f'{len(predict_var_rp)} == {len(features["vars_rp_varName"])}'
    assert len(pre_cons) == len(features["consName"]), f'{len(pre_cons)} == {len(features["consName"])}'
    # align the variable name betweend the output and the solver
    # var构建 scores
    var_x_scores = []
    for i in range(len(predict_var_x)):
        var_x_scores.append([i,features["vars_x_varName"][i], predict_var_x[i].item(), -1, 'BINARY'])
    var_x_scores.sort(key=lambda x: x[2], reverse=True)  # reverse=True，按概率从大到小排序
    var_rp_scores = []
    for i in range(len(predict_var_rp)):
        var_rp_scores.append([i, features["vars_rp_varName"][i], predict_var_rp[i].item(), -1, 'BINARY'])
    var_rp_scores.sort(key=lambda x: x[2], reverse=True)  # reverse=True，按概率从大到小排

    constr_scores = []
    for i in range(len(pre_cons)):
        constr_scores.append([i, consName[i], pre_cons[i].item(), -1])
    constr_scores.sort(key=lambda x: x[2], reverse=True)  # reverse=True，按概率从大到小排序

    return BD, var_rp_scores, var_x_scores, constr_scores

def fix_variable(optvFixedModel, optv_variabels_map):
    var_fixer = 0
    count0_x = 0
    for i in range(len(var_x_scores)):
        if count0_x < k0_var_x:
            var_x_scores[i][3] = 0  # 概率大的固定为0
            count0_x += 1
            var_fixer += 1
    count0_rp = 0
    for i in range(len(var_rp_scores)):
        if count0_rp < k0_var_rp:
            var_rp_scores[i][3] = 0  # 概率大的固定为0
            count0_rp += 1
            var_fixer += 1
    print(f'instance: {test_ins_name}, '
                f'fix x {count0_x} 0s and '
                f'fix rp {count0_rp} 0s, delta {delta_x}. ')
    fixVarNum = 0
    fixVarNum_x = 0
    tmp_var_xs = []
    for i in range(len(var_x_scores)):
        if var_x_scores[i][3] < 0:
            continue
        else: # set to 0
            tar_var = optv_variabels_map[var_x_scores[i][1]]
            x_star = var_x_scores[i][3]
            if x_star == 0:
                if delta_x <= 0:
                    UB = tar_var.Get(optvpy.OPTVDblAttr.UB)
                    LB = tar_var.Get(optvpy.OPTVDblAttr.LB)
                    tar_var.Set(optvpy.OPTVDblAttr.UB, LB)
                else:
                    tmp_var_x = optvFixedModel.AddVar(lb=0,ub=optvpy.OPTV_INF,obj=0,type=optvpy.OPTV_CONTINUOUS, name=f'tmp_var_x-{var_x_scores[i][1]}')
                    tmp_var_xs.append(tmp_var_x)
                    optvFixedModel.AddConstr(tmp_var_x - tar_var, lhs=0, rhs=optvpy.OPTV_INF, name=f'tmp_var_x_constr0-{var_x_scores[i][1]}')
                    optvFixedModel.AddConstr(tmp_var_x + tar_var, lhs=0, rhs=optvpy.OPTV_INF, name=f'tmp_var_x_constr1-{var_x_scores[i][1]}')
                fixVarNum_x += 1
    if len(tmp_var_xs) > 0:
        all_tmp_x = 0
        for tmp_var in tmp_var_xs:
            all_tmp_x+=tmp_var
        optvFixedModel.AddConstr(all_tmp_x-delta_x, lhs=-optvpy.OPTV_INF, rhs=0, name=f'tmp_var_x_constr-delta')
    # 固定rp变量
    fixVarNum_rp = 0
    tmp_var_rps = []
    for i in range(len(var_rp_scores)):
        if var_rp_scores[i][3] < 0:
            continue
        else: # set to 0
            tar_var = optv_variabels_map[var_rp_scores[i][1]]
            x_star = var_rp_scores[i][3]
            if x_star == 0:
                if delta_rp <= 0:
                    UB = tar_var.Get(optvpy.OPTVDblAttr.UB)
                    LB = tar_var.Get(optvpy.OPTVDblAttr.LB)
                    tar_var.Set(optvpy.OPTVDblAttr.UB, LB)
                else:
                    tmp_var_rp = optvFixedModel.AddVar(lb=0, ub=optvpy.OPTV_INF, obj=0, type=optvpy.OPTV_CONTINUOUS,
                                                      name=f'tmp_var_rp-{var_rp_scores[i][1]}')
                    tmp_var_rps.append(tmp_var_rp)
                    optvFixedModel.AddConstr(tmp_var_rp - tar_var, lhs=0, rhs=optvpy.OPTV_INF,
                                             name=f'tmp_var_rp_constr0-{var_rp_scores[i][1]}')
                    optvFixedModel.AddConstr(tmp_var_rp + tar_var, lhs=0, rhs=optvpy.OPTV_INF,
                                             name=f'tmp_var_rp_constr1-{var_rp_scores[i][1]}')
                fixVarNum_rp += 1
    if len(tmp_var_rps) > 0 :
        all_tmp_rp = 0
        for tmp_var in tmp_var_rps:
            all_tmp_rp+=tmp_var
        optvFixedModel.AddConstr(all_tmp_rp-delta_rp, lhs=-optvpy.OPTV_INF, rhs=0, name=f'tmp_var_rp_constr-delta')
    fixVarNum = fixVarNum_x + fixVarNum_rp
    return optvFixedModel, fixVarNum

def fix_constraints(optvFixedModel, BD, constr_scores):
    pre_cons, predict_var_x, predict_var_rp = BD
    constr_fixer = 0
    count_tight_rp_max = 0
    for i in range(len(pre_cons)):
        if count_tight_rp_max < tight_constr_rp_max:
            constr_scores[i][3] = 1  # 概率大的固定为tight constraint
            count_tight_rp_max += 1
            constr_fixer += 1
    for score in constr_scores:
        if score[3] == 1: # tight constr
            con = optvFixedModel.GetConstrByName(score[1])
            UB = con.Get(optvpy.OPTVDblAttr.UB)
            con.Set(optvpy.OPTVDblAttr.LB, UB)
    return optvFixedModel
    
features, consName = get_features(ins_name_to_read)
BD, var_rp_scores, var_x_scores, constr_scores = forward(features, policy)

k0_var_x = int(k0_var_x_ratio * len(BD[1]))
k0_var_rp = int(k0_var_rp_ratio*len(BD[2]))
tight_constr_rp_max = int(tight_constr_rp_max_ratio * len(BD[0]))

optvLogPath = f'{log_folder}/optv_fixed_{test_ins_name}.log'
optvEnv = optvpy.OPTVEnv(optvLogPath)
optvFixedModel = optvpy.OPTVModel(optvEnv)
optvFixedModel.Read(ins_name_to_read)
allVars = optvFixedModel.GetVars()
sortedAllVars = sorted(allVars, key=lambda v: v.Get(optvpy.OPTVStrAttr.NAME))
optv_variabels_map = {}
for v in sortedAllVars:  # get a dict (variable map), varname:var clasee
    optv_variabels_map[v.Get(optvpy.OPTVStrAttr.NAME)] = v

optvFixedModel = fix_variable(optvFixedModel, optv_variabels_map)
optvFixedModel = fix_constraints(optvFixedModel, BD, constr_scores)

optvFixedModel.Update()
optvFixedModel.Optimize()

